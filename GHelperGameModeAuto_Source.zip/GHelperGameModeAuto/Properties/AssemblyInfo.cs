using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("GHelperGameModeAuto")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("Auto switch G-Helper modes based on running games")]
[assembly: AssemblyFileVersion("1.0.2.0")]
[assembly: AssemblyInformationalVersion("1.0.2")]
[assembly: AssemblyProduct("G-Helper Game Mode Auto Switcher")]
[assembly: AssemblyTitle("GHelperGameModeAuto")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: AssemblyVersion("1.0.2.0")]
