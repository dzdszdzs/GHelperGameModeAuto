using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using GHelperGameModeAuto.Models;
using GHelperGameModeAuto.Services;
using GHelperGameModeAuto.Views;

namespace GHelperGameModeAuto;

public class MainWindow : Window, IComponentConnector, IStyleConnector
{
	private readonly ConfigService _configService;

	private readonly ProcessMonitorService _monitorService;

	private readonly ObservableCollection<GameConfig> _gamesCollection = new ObservableCollection<GameConfig>();

	private bool _isExplicitExit;

	private bool _hasShownTrayTip;

	internal Border BadgeStatus;

	internal Ellipse DotStatus;

	internal TextBlock TxtStatus;

	internal Button BtnTogglePause;

	internal TextBlock TxtCurrentModeIcon;

	internal TextBlock TxtCurrentModeName;

	internal TextBlock TxtCurrentModeHotkey;

	internal TextBlock TxtActiveGameName;

	internal TextBlock TxtActiveGameDetail;

	internal TextBlock TxtBaselineMode;

	internal TextBox TxtLiveLogs;

	internal TextBox TxtGameSearch;

	internal DataGrid GridGames;

	internal TextBlock TxtHotkeySilent;

	internal TextBlock TxtHotkeyBalanced;

	internal TextBlock TxtHotkeyTurbo;

	internal TextBlock TxtHotkeyCustom1;

	internal TextBlock TxtHotkeyCustom2;

	internal CheckBox ChkAutoStart;

	internal CheckBox ChkMinimizeToTrayOnClose;

	internal CheckBox ChkStartMinimized;

	internal Slider SliderInterval;

	internal TextBlock TxtIntervalDisplay;

	internal ComboBox CmbDefaultBaseline;

	internal TextBlock TxtFooterStatus;

	private bool _contentLoaded;

	private readonly System.Windows.Threading.DispatcherTimer _intervalSaveDebounceTimer;

	private static readonly Dictionary<string, SolidColorBrush> _brushCache = new Dictionary<string, SolidColorBrush>(StringComparer.OrdinalIgnoreCase);

	public MainWindow(ConfigService configService, ProcessMonitorService monitorService)
	{
		InitializeComponent();
		WindowHelper.ApplyDarkThemeAndIcon(this);
		_configService = configService;
		_monitorService = monitorService;
		_intervalSaveDebounceTimer = new System.Windows.Threading.DispatcherTimer
		{
			Interval = TimeSpan.FromMilliseconds(400)
		};
		_intervalSaveDebounceTimer.Tick += (s, e) =>
		{
			_intervalSaveDebounceTimer.Stop();
			_configService.Save();
		};
		InitUiState();
		BindEvents();
	}

	private void InitUiState()
	{
		RefreshGamesGrid();
		ChkAutoStart.IsChecked = AutoStartService.IsAutoStartEnabled();
		ChkMinimizeToTrayOnClose.IsChecked = _configService.Current.MinimizeToTrayOnClose;
		ChkStartMinimized.IsChecked = _configService.Current.StartMinimized;
		SliderInterval.Value = _configService.Current.PollingIntervalMs;
		TxtIntervalDisplay.Text = $"{_configService.Current.PollingIntervalMs}ms";
		var itemsSource = (from m in Enum.GetValues<GHelperMode>()
			select new
			{
				Mode = m,
				Name = m.ToDisplayName()
			}).ToList();
		CmbDefaultBaseline.ItemsSource = itemsSource;
		CmbDefaultBaseline.DisplayMemberPath = "Name";
		CmbDefaultBaseline.SelectedValuePath = "Mode";
		CmbDefaultBaseline.SelectedValue = _configService.Current.DefaultBaselineMode;
		RefreshHotkeyTexts();
		UpdateModeCard(_monitorService.CurrentMode);
		UpdateActiveGameCard(_monitorService.ActiveGame);
		UpdatePauseStateUi(_monitorService.IsPaused);
		CleanUpStaticUi();
		base.Loaded += delegate
		{
			CleanUpStaticUi();
		};
		GridGames.CellEditEnding += (s, e) =>
		{
			Dispatcher.BeginInvoke(new Action(() =>
			{
				_configService.Save();
			}));
		};
	}

	private void CleanUpStaticUi()
	{
		try
		{
			foreach (TextBlock tb in WindowHelper.FindLogicalChildren<TextBlock>(this))
			{
				if (tb.Text != null && tb.Text.Contains("Portable Edition"))
				{
					tb.Visibility = Visibility.Collapsed;
					tb.Height = 0;
					tb.Text = "";
				}
				else if (tb.Text != null && (tb.Text.Trim() == "⚡ Turbo" || tb.Text.Trim() == "Turbo"))
				{
					tb.Text = "⚡ 增强 (Turbo)";
				}
			}
			foreach (Button btn in WindowHelper.FindLogicalChildren<Button>(this))
			{
				if (btn.Content is string s && s.Trim() == "⚡ Turbo")
				{
					btn.Content = "⚡ 增强";
				}
			}
		}
		catch
		{
		}
	}

	private void BindEvents()
	{
		_monitorService.ModeChanged += delegate(GHelperMode mode)
		{
			((DispatcherObject)this).Dispatcher.Invoke((Action)delegate
			{
				UpdateModeCard(mode);
			});
		};
		_monitorService.ActiveGameChanged += delegate(GameConfig? game)
		{
			GameConfig game2 = game;
			((DispatcherObject)this).Dispatcher.Invoke((Action)delegate
			{
				UpdateActiveGameCard(game2);
			});
		};
		_monitorService.PauseStateChanged += delegate(bool paused)
		{
			((DispatcherObject)this).Dispatcher.Invoke((Action)delegate
			{
				UpdatePauseStateUi(paused);
			});
		};
		_monitorService.StatusMessageChanged += delegate(string msg)
		{
			string msg2 = msg;
			((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => TxtFooterStatus.Text = msg2));
		};
		Logger.LogAdded += delegate(string logLine)
		{
			string logLine2 = logLine;
			((DispatcherObject)this).Dispatcher.Invoke((Action)delegate
			{
				if (TxtLiveLogs.Text.Length > 20000)
				{
					TxtLiveLogs.Text = TxtLiveLogs.Text.Substring(TxtLiveLogs.Text.Length - 10000);
				}
				TxtLiveLogs.AppendText(logLine2 + Environment.NewLine);
				TxtLiveLogs.ScrollToEnd();
			});
		};
	}

	private static SolidColorBrush BrushFromHex(string hex)
	{
		if (!_brushCache.TryGetValue(hex, out var brush))
		{
			brush = (SolidColorBrush)new BrushConverter().ConvertFromString(hex)!;
			brush.Freeze();
			_brushCache[hex] = brush;
		}
		return brush;
	}

	private void UpdateModeCard(GHelperMode mode)
	{
		TxtCurrentModeIcon.Text = mode.GetIconSymbol();
		TxtCurrentModeName.Text = mode.ToShortName();
		TxtCurrentModeName.Foreground = BrushFromHex(mode.GetColorHex());
		HotkeyConfig hotkey = _configService.Current.GetHotkey(mode);
		TxtCurrentModeHotkey.Text = "快捷键: " + hotkey.DisplayText;
		TxtBaselineMode.Text = _monitorService.PreGameMode.ToDisplayName();
	}

	private void UpdateActiveGameCard(GameConfig? game)
	{
		if (game != null)
		{
			TxtActiveGameName.Text = game.Name;
			TxtActiveGameName.Foreground = BrushFromHex("#34D399");
			TxtActiveGameDetail.Text = "进程: " + game.ProcessName + ".exe | 启动模式: " + game.LaunchMode.ToShortName();
		}
		else
		{
			TxtActiveGameName.Text = "无游戏运行";
			TxtActiveGameName.Foreground = BrushFromHex("#FAFAFA");
			TxtActiveGameDetail.Text = "后台持续监听配置的游戏进程...";
		}
	}

	private void UpdatePauseStateUi(bool isPaused)
	{
		if (isPaused)
		{
			BtnTogglePause.Content = "▶ 恢复切换";
			DotStatus.Fill = BrushFromHex("#EF4444");
			TxtStatus.Text = "自动切换已暂停";
			TxtStatus.Foreground = BrushFromHex("#F87171");
			BadgeStatus.Background = BrushFromHex("#450A0A");
		}
		else
		{
			BtnTogglePause.Content = "⏸ 暂停切换";
			DotStatus.Fill = BrushFromHex("#10B981");
			TxtStatus.Text = "自动切换运行中";
			TxtStatus.Foreground = BrushFromHex("#34D399");
			BadgeStatus.Background = BrushFromHex("#064E3B");
		}
	}

	private void RefreshHotkeyTexts()
	{
		TxtHotkeySilent.Text = _configService.Current.GetHotkey(GHelperMode.Silent).DisplayText;
		TxtHotkeyBalanced.Text = _configService.Current.GetHotkey(GHelperMode.Balanced).DisplayText;
		TxtHotkeyTurbo.Text = _configService.Current.GetHotkey(GHelperMode.Turbo).DisplayText;
		TxtHotkeyCustom1.Text = _configService.Current.GetHotkey(GHelperMode.Custom1).DisplayText;
		TxtHotkeyCustom2.Text = _configService.Current.GetHotkey(GHelperMode.Custom2).DisplayText;
	}

	private void RefreshGamesGrid(string? searchKeyword = null)
	{
		string searchKeyword2 = searchKeyword;
		_gamesCollection.Clear();
		IEnumerable<GameConfig> enumerable = _configService.Current.Games.AsEnumerable();
		if (!string.IsNullOrWhiteSpace(searchKeyword2))
		{
			enumerable = enumerable.Where((GameConfig g) => g.Name.Contains(searchKeyword2, StringComparison.OrdinalIgnoreCase) || g.ProcessName.Contains(searchKeyword2, StringComparison.OrdinalIgnoreCase));
		}
		foreach (GameConfig item in enumerable)
		{
			_gamesCollection.Add(item);
		}
		GridGames.ItemsSource = null;
		GridGames.ItemsSource = _gamesCollection;
	}

	private void BtnTogglePause_Click(object sender, RoutedEventArgs e)
	{
		_monitorService.SetPaused(!_monitorService.IsPaused);
	}

	private void ManualSwitch_Silent(object sender, RoutedEventArgs e)
	{
		_monitorService.ManualSwitchMode(GHelperMode.Silent);
	}

	private void ManualSwitch_Balanced(object sender, RoutedEventArgs e)
	{
		_monitorService.ManualSwitchMode(GHelperMode.Balanced);
	}

	private void ManualSwitch_Turbo(object sender, RoutedEventArgs e)
	{
		_monitorService.ManualSwitchMode(GHelperMode.Turbo);
	}

	private void ManualSwitch_Custom1(object sender, RoutedEventArgs e)
	{
		_monitorService.ManualSwitchMode(GHelperMode.Custom1);
	}

	private void ManualSwitch_Custom2(object sender, RoutedEventArgs e)
	{
		_monitorService.ManualSwitchMode(GHelperMode.Custom2);
	}

	private void BtnClearLog_Click(object sender, RoutedEventArgs e)
	{
		TxtLiveLogs.Clear();
	}

	private void BtnOpenLogFile_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = Logger.LogFilePath,
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, "打开日志异常: " + ex.Message, "提示", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}
	}

	private void BtnAddGame_Click(object sender, RoutedEventArgs e)
	{
		AddGameDialog addGameDialog = new AddGameDialog();
		addGameDialog.Owner = this;
		if (addGameDialog.ShowDialog().GetValueOrDefault())
		{
			GameConfig resultConfig = addGameDialog.ResultConfig;
			_configService.Current.Games.Add(resultConfig);
			_configService.Save();
			RefreshGamesGrid(TxtGameSearch.Text);
			Logger.Info($"已添加新游戏配置: {resultConfig.Name} ({resultConfig.ProcessName}.exe)");
		}
	}

	private void BtnScanGames_Click(object sender, RoutedEventArgs e)
	{
		ScanGamesDialog scanGamesDialog = new ScanGamesDialog();
		scanGamesDialog.Owner = this;
		if (!scanGamesDialog.ShowDialog().GetValueOrDefault())
		{
			return;
		}
		int num = 0;
		HashSet<string> hashSet = _configService.Current.Games.Select((GameConfig x) => x.CleanProcessName).ToHashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (GameConfig importedGame in scanGamesDialog.ImportedGames)
		{
			if (!hashSet.Contains(importedGame.CleanProcessName))
			{
				_configService.Current.Games.Add(importedGame);
				hashSet.Add(importedGame.CleanProcessName);
				num++;
			}
		}
		if (num > 0)
		{
			_configService.Save();
			RefreshGamesGrid(TxtGameSearch.Text);
			MessageBox.Show(this, $"成功导入 {num} 款游戏！", "导入完成", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			Logger.Info($"从游戏库扫描成功导入 {num} 款新游戏");
		}
		else
		{
			MessageBox.Show(this, "所选游戏均已存在于列表中，未重复导入。", "提示", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
	}

	private void BtnEditGame_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is Button { DataContext: var dataContext }))
		{
			return;
		}
		GameConfig game = dataContext as GameConfig;
		if (game == null)
		{
			return;
		}
		AddGameDialog addGameDialog = new AddGameDialog(game);
		addGameDialog.Owner = this;
		if (addGameDialog.ShowDialog().GetValueOrDefault())
		{
			int num = _configService.Current.Games.FindIndex((GameConfig g) => g.Id == game.Id);
			if (num >= 0)
			{
				_configService.Current.Games[num] = addGameDialog.ResultConfig;
				_configService.Save();
				RefreshGamesGrid(TxtGameSearch.Text);
				Logger.Info("已更新游戏配置: " + addGameDialog.ResultConfig.Name);
			}
		}
	}

	private void BtnDeleteGame_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is Button { DataContext: var dataContext }))
		{
			return;
		}
		GameConfig game = dataContext as GameConfig;
		if (game != null && MessageBox.Show(this, "确定要删除游戏 [" + game.Name + "] 的自动切换配置吗？", "确认删除", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
		{
			_configService.Current.Games.RemoveAll((GameConfig g) => g.Id == game.Id);
			_configService.Save();
			RefreshGamesGrid(TxtGameSearch.Text);
			Logger.Info("已删除游戏配置: " + game.Name);
		}
	}

	private void TxtGameSearch_TextChanged(object sender, TextChangedEventArgs e)
	{
		RefreshGamesGrid(TxtGameSearch.Text);
	}

	private void EditHotkey(GHelperMode mode)
	{
		HotkeyConfig hotkey = _configService.Current.GetHotkey(mode);
		HotkeyRecordDialog hotkeyRecordDialog = new HotkeyRecordDialog(mode, hotkey);
		hotkeyRecordDialog.Owner = this;
		if (hotkeyRecordDialog.ShowDialog().GetValueOrDefault())
		{
			_configService.Current.SetHotkey(mode, hotkeyRecordDialog.ResultConfig);
			_configService.Save();
			RefreshHotkeyTexts();
			UpdateModeCard(_monitorService.CurrentMode);
			Logger.Info("已更新模式 " + mode.ToDisplayName() + " 的快捷键为: " + hotkeyRecordDialog.ResultConfig.DisplayText);
		}
	}

	private void TestHotkey(GHelperMode mode)
	{
		HotkeyConfig hotkey = _configService.Current.GetHotkey(mode);
		if (HotkeySender.Send(hotkey))
		{
			MessageBox.Show(this, "已向系统发送快捷键: " + hotkey.DisplayText + "\n请检查 G-Helper 是否已切换至对应模式。", "按键测试", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
		else
		{
			MessageBox.Show(this, "按键发送失败，请查看日志！", "错误", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}
	}

	private void EditHotkey_Silent(object sender, RoutedEventArgs e)
	{
		EditHotkey(GHelperMode.Silent);
	}

	private void EditHotkey_Balanced(object sender, RoutedEventArgs e)
	{
		EditHotkey(GHelperMode.Balanced);
	}

	private void EditHotkey_Turbo(object sender, RoutedEventArgs e)
	{
		EditHotkey(GHelperMode.Turbo);
	}

	private void EditHotkey_Custom1(object sender, RoutedEventArgs e)
	{
		EditHotkey(GHelperMode.Custom1);
	}

	private void EditHotkey_Custom2(object sender, RoutedEventArgs e)
	{
		EditHotkey(GHelperMode.Custom2);
	}

	private void TestHotkey_Silent(object sender, RoutedEventArgs e)
	{
		TestHotkey(GHelperMode.Silent);
	}

	private void TestHotkey_Balanced(object sender, RoutedEventArgs e)
	{
		TestHotkey(GHelperMode.Balanced);
	}

	private void TestHotkey_Turbo(object sender, RoutedEventArgs e)
	{
		TestHotkey(GHelperMode.Turbo);
	}

	private void TestHotkey_Custom1(object sender, RoutedEventArgs e)
	{
		TestHotkey(GHelperMode.Custom1);
	}

	private void TestHotkey_Custom2(object sender, RoutedEventArgs e)
	{
		TestHotkey(GHelperMode.Custom2);
	}

	private void ChkAutoStart_Click(object sender, RoutedEventArgs e)
	{
		bool valueOrDefault = ChkAutoStart.IsChecked.GetValueOrDefault();
		if (AutoStartService.SetAutoStart(valueOrDefault))
		{
			_configService.Current.AutoStart = valueOrDefault;
			_configService.Save();
		}
		else
		{
			ChkAutoStart.IsChecked = !valueOrDefault;
			MessageBox.Show(this, "修改开机自启动设置失败，请检查启动文件夹权限。", "提示", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}
	}

	private void ChkMinimizeToTray_Click(object sender, RoutedEventArgs e)
	{
		_configService.Current.MinimizeToTrayOnClose = ChkMinimizeToTrayOnClose.IsChecked.GetValueOrDefault();
		_configService.Save();
	}

	private void ChkStartMinimized_Click(object sender, RoutedEventArgs e)
	{
		_configService.Current.StartMinimized = ChkStartMinimized.IsChecked.GetValueOrDefault();
		_configService.Save();
	}

	private void SliderInterval_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
	{
		if (TxtIntervalDisplay != null && _configService != null)
		{
			int num = (int)SliderInterval.Value;
			TxtIntervalDisplay.Text = $"{num}ms";
			_configService.Current.PollingIntervalMs = num;
			_monitorService.UpdateInterval(num);
			_intervalSaveDebounceTimer.Stop();
			_intervalSaveDebounceTimer.Start();
		}
	}

	private void CmbDefaultBaseline_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		if (CmbDefaultBaseline.SelectedValue is GHelperMode gHelperMode)
		{
			_configService.Current.DefaultBaselineMode = gHelperMode;
			_configService.Save();
			_monitorService.CalibrateMode(gHelperMode);
		}
	}

	private void OpenAppDir_Click(object sender, RoutedEventArgs e)
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = AppContext.BaseDirectory,
			UseShellExecute = true
		});
	}

	private void OpenConfigDir_Click(object sender, RoutedEventArgs e)
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = _configService.ConfigDirectory,
			UseShellExecute = true
		});
	}

	private void OpenLogsDir_Click(object sender, RoutedEventArgs e)
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = Logger.LogDirectory,
			UseShellExecute = true
		});
	}

	public void ForceExit()
	{
		if (_intervalSaveDebounceTimer.IsEnabled)
		{
			_intervalSaveDebounceTimer.Stop();
			_configService.Save();
		}
		_isExplicitExit = true;
		Close();
	}

	protected override void OnClosing(CancelEventArgs e)
	{
		if (_intervalSaveDebounceTimer.IsEnabled)
		{
			_intervalSaveDebounceTimer.Stop();
			_configService.Save();
		}
		if (!_isExplicitExit && _configService.Current.MinimizeToTrayOnClose)
		{
			e.Cancel = true;
			Hide();
			MemoryOptimizer.TrimMemory();
			if (!_hasShownTrayTip)
			{
				_hasShownTrayTip = true;
				((App)Application.Current).TrayManager?.ShowNotification("G-Helper 自动切换已最小化", "程序正在系统托盘保持后台运行，已自动压缩后台内存至极低占用。双击托盘图标可重新打开主界面。");
			}
		}
		else
		{
			base.OnClosing(e);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/GHelperGameModeAuto;component/mainwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			BadgeStatus = (Border)target;
			break;
		case 2:
			DotStatus = (Ellipse)target;
			break;
		case 3:
			TxtStatus = (TextBlock)target;
			break;
		case 4:
			BtnTogglePause = (Button)target;
			BtnTogglePause.Click += BtnTogglePause_Click;
			break;
		case 5:
			TxtCurrentModeIcon = (TextBlock)target;
			break;
		case 6:
			TxtCurrentModeName = (TextBlock)target;
			break;
		case 7:
			TxtCurrentModeHotkey = (TextBlock)target;
			break;
		case 8:
			TxtActiveGameName = (TextBlock)target;
			break;
		case 9:
			TxtActiveGameDetail = (TextBlock)target;
			break;
		case 10:
			TxtBaselineMode = (TextBlock)target;
			break;
		case 11:
			((Button)target).Click += ManualSwitch_Silent;
			break;
		case 12:
			((Button)target).Click += ManualSwitch_Balanced;
			break;
		case 13:
			((Button)target).Click += ManualSwitch_Turbo;
			break;
		case 14:
			((Button)target).Click += ManualSwitch_Custom1;
			break;
		case 15:
			((Button)target).Click += ManualSwitch_Custom2;
			break;
		case 16:
			((Button)target).Click += BtnClearLog_Click;
			break;
		case 17:
			((Button)target).Click += BtnOpenLogFile_Click;
			break;
		case 18:
			TxtLiveLogs = (TextBox)target;
			break;
		case 19:
			((Button)target).Click += BtnAddGame_Click;
			break;
		case 20:
			((Button)target).Click += BtnScanGames_Click;
			break;
		case 21:
			TxtGameSearch = (TextBox)target;
			TxtGameSearch.TextChanged += TxtGameSearch_TextChanged;
			break;
		case 22:
			GridGames = (DataGrid)target;
			break;
		case 25:
			TxtHotkeySilent = (TextBlock)target;
			break;
		case 26:
			((Button)target).Click += TestHotkey_Silent;
			break;
		case 27:
			((Button)target).Click += EditHotkey_Silent;
			break;
		case 28:
			TxtHotkeyBalanced = (TextBlock)target;
			break;
		case 29:
			((Button)target).Click += TestHotkey_Balanced;
			break;
		case 30:
			((Button)target).Click += EditHotkey_Balanced;
			break;
		case 31:
			TxtHotkeyTurbo = (TextBlock)target;
			break;
		case 32:
			((Button)target).Click += TestHotkey_Turbo;
			break;
		case 33:
			((Button)target).Click += EditHotkey_Turbo;
			break;
		case 34:
			TxtHotkeyCustom1 = (TextBlock)target;
			break;
		case 35:
			((Button)target).Click += TestHotkey_Custom1;
			break;
		case 36:
			((Button)target).Click += EditHotkey_Custom1;
			break;
		case 37:
			TxtHotkeyCustom2 = (TextBlock)target;
			break;
		case 38:
			((Button)target).Click += TestHotkey_Custom2;
			break;
		case 39:
			((Button)target).Click += EditHotkey_Custom2;
			break;
		case 40:
			ChkAutoStart = (CheckBox)target;
			ChkAutoStart.Click += ChkAutoStart_Click;
			break;
		case 41:
			ChkMinimizeToTrayOnClose = (CheckBox)target;
			ChkMinimizeToTrayOnClose.Click += ChkMinimizeToTray_Click;
			break;
		case 42:
			ChkStartMinimized = (CheckBox)target;
			ChkStartMinimized.Click += ChkStartMinimized_Click;
			break;
		case 43:
			SliderInterval = (Slider)target;
			SliderInterval.ValueChanged += SliderInterval_ValueChanged;
			break;
		case 44:
			TxtIntervalDisplay = (TextBlock)target;
			break;
		case 45:
			CmbDefaultBaseline = (ComboBox)target;
			CmbDefaultBaseline.SelectionChanged += CmbDefaultBaseline_SelectionChanged;
			break;
		case 46:
			((Button)target).Click += OpenAppDir_Click;
			break;
		case 47:
			((Button)target).Click += OpenConfigDir_Click;
			break;
		case 48:
			((Button)target).Click += OpenLogsDir_Click;
			break;
		case 49:
			TxtFooterStatus = (TextBlock)target;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IStyleConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 23:
			((Button)target).Click += BtnEditGame_Click;
			break;
		case 24:
			((Button)target).Click += BtnDeleteGame_Click;
			break;
		}
	}
}
