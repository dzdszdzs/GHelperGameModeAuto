using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using GHelperGameModeAuto.Models;
using GHelperGameModeAuto.Services;
using Microsoft.Win32;

namespace GHelperGameModeAuto.Views;

public class AddGameDialog : Window, IComponentConnector
{
	internal TextBlock TitleTextBlock;

	internal TextBox TxtExePath;

	internal TextBox TxtGameName;

	internal TextBox TxtProcessName;

	internal ComboBox CmbLaunchMode;

	internal RadioButton RbRestorePrevious;

	internal RadioButton RbFixedMode;

	internal ComboBox CmbFixedExitMode;

	internal CheckBox ChkIsEnabled;

	private bool _contentLoaded;

	public GameConfig ResultConfig { get; private set; }

	public AddGameDialog(GameConfig? existingConfig = null)
	{
		InitializeComponent();
		WindowHelper.ApplyDarkThemeAndIcon(this);
		var itemsSource = (from m in Enum.GetValues<GHelperMode>()
			select new
			{
				Mode = m,
				Name = m.ToDisplayName()
			}).ToList();
		CmbLaunchMode.ItemsSource = itemsSource;
		CmbLaunchMode.DisplayMemberPath = "Name";
		CmbLaunchMode.SelectedValuePath = "Mode";
		CmbFixedExitMode.ItemsSource = itemsSource;
		CmbFixedExitMode.DisplayMemberPath = "Name";
		CmbFixedExitMode.SelectedValuePath = "Mode";
		if (existingConfig != null)
		{
			ResultConfig = existingConfig.Clone();
			TitleTextBlock.Text = "\ud83c\udfae 编辑游戏配置";
			base.Title = "编辑游戏配置";
			TxtGameName.Text = ResultConfig.Name;
			TxtProcessName.Text = ResultConfig.ProcessName;
			TxtExePath.Text = ResultConfig.ExecutablePath;
			CmbLaunchMode.SelectedValue = ResultConfig.LaunchMode;
			if (ResultConfig.ExitBehavior == ExitModeType.RestorePrevious)
			{
				RbRestorePrevious.IsChecked = true;
				CmbFixedExitMode.IsEnabled = false;
			}
			else
			{
				RbFixedMode.IsChecked = true;
				CmbFixedExitMode.IsEnabled = true;
				CmbFixedExitMode.SelectedValue = ResultConfig.FixedExitMode;
			}
			ChkIsEnabled.IsChecked = ResultConfig.IsEnabled;
		}
		else
		{
			ResultConfig = new GameConfig();
			CmbLaunchMode.SelectedValue = GHelperMode.Turbo;
			CmbFixedExitMode.SelectedValue = GHelperMode.Balanced;
		}
	}

	private void BrowseExe_Click(object sender, RoutedEventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*",
			Title = "选择游戏可执行文件 (EXE)"
		};
		if (!openFileDialog.ShowDialog(this).GetValueOrDefault())
		{
			return;
		}
		string fileName = openFileDialog.FileName;
		TxtExePath.Text = fileName;
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);
		TxtProcessName.Text = fileNameWithoutExtension;
		try
		{
			FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(fileName);
			string text = versionInfo.FileDescription;
			if (string.IsNullOrWhiteSpace(text))
			{
				text = versionInfo.ProductName;
			}
			TxtGameName.Text = ((!string.IsNullOrWhiteSpace(text)) ? text : fileNameWithoutExtension);
		}
		catch
		{
			TxtGameName.Text = fileNameWithoutExtension;
		}
	}

	private void ExitModeRadio_Changed(object sender, RoutedEventArgs e)
	{
		if (CmbFixedExitMode != null)
		{
			CmbFixedExitMode.IsEnabled = RbFixedMode.IsChecked.GetValueOrDefault();
		}
	}

	private void Save_Click(object sender, RoutedEventArgs e)
	{
		string text = TxtGameName.Text.Trim();
		string text2 = TxtProcessName.Text.Trim();
		if (string.IsNullOrWhiteSpace(text))
		{
			MessageBox.Show(this, "请输入游戏显示名称", "提示", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			return;
		}
		if (string.IsNullOrWhiteSpace(text2))
		{
			MessageBox.Show(this, "请输入游戏进程名称", "提示", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			return;
		}
		if (text2.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
		{
			string text3 = text2;
			text2 = text3.Substring(0, text3.Length - 4);
		}
		ResultConfig.Name = text;
		ResultConfig.ProcessName = text2;
		ResultConfig.ExecutablePath = TxtExePath.Text.Trim();
		ResultConfig.LaunchMode = (GHelperMode)(CmbLaunchMode.SelectedValue ?? ((object)GHelperMode.Turbo));
		ResultConfig.ExitBehavior = ((!RbRestorePrevious.IsChecked.GetValueOrDefault()) ? ExitModeType.FixedMode : ExitModeType.RestorePrevious);
		ResultConfig.FixedExitMode = (GHelperMode)(CmbFixedExitMode.SelectedValue ?? ((object)GHelperMode.Balanced));
		ResultConfig.IsEnabled = ChkIsEnabled.IsChecked.GetValueOrDefault();
		base.DialogResult = true;
		Close();
	}

	private void Cancel_Click(object sender, RoutedEventArgs e)
	{
		base.DialogResult = false;
		Close();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/GHelperGameModeAuto;component/views/addgamedialog.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			TitleTextBlock = (TextBlock)target;
			break;
		case 2:
			TxtExePath = (TextBox)target;
			break;
		case 3:
			((Button)target).Click += BrowseExe_Click;
			break;
		case 4:
			TxtGameName = (TextBox)target;
			break;
		case 5:
			TxtProcessName = (TextBox)target;
			break;
		case 6:
			CmbLaunchMode = (ComboBox)target;
			break;
		case 7:
			RbRestorePrevious = (RadioButton)target;
			RbRestorePrevious.Checked += ExitModeRadio_Changed;
			break;
		case 8:
			RbFixedMode = (RadioButton)target;
			RbFixedMode.Checked += ExitModeRadio_Changed;
			break;
		case 9:
			CmbFixedExitMode = (ComboBox)target;
			break;
		case 10:
			ChkIsEnabled = (CheckBox)target;
			break;
		case 11:
			((Button)target).Click += Cancel_Click;
			break;
		case 12:
			((Button)target).Click += Save_Click;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
