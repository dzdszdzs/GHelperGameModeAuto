using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using GHelperGameModeAuto.Models;
using GHelperGameModeAuto.Services;

namespace GHelperGameModeAuto.Views;

public class HotkeyRecordDialog : Window, IComponentConnector
{
	private class VirtualKeyItem
	{
		public string Name { get; set; } = string.Empty;


		public byte VirtualKey { get; set; }

		public override string ToString()
		{
			return Name;
		}
	}

	private readonly GHelperMode _mode;

	private bool _isUpdatingUi;

	internal TextBlock TxtModeTitle;

	internal TextBlock TxtPreview;

	internal Border CaptureBorder;

	internal TextBlock TxtCaptureHint;

	internal CheckBox ChkCtrl;

	internal CheckBox ChkShift;

	internal CheckBox ChkAlt;

	internal CheckBox ChkWin;

	internal ComboBox CmbVirtualKeys;

	private bool _contentLoaded;

	public HotkeyConfig ResultConfig { get; private set; }

	public HotkeyRecordDialog(GHelperMode mode, HotkeyConfig currentConfig)
	{
		InitializeComponent();
		WindowHelper.ApplyDarkThemeAndIcon(this);
		_mode = mode;
		ResultConfig = currentConfig.Clone();
		TxtModeTitle.Text = "⌨ 修改快捷键 - " + mode.ToDisplayName();
		InitVirtualKeysCombo();
		LoadConfigToUi();
	}

	private void InitVirtualKeysCombo()
	{
		List<VirtualKeyItem> list = new List<VirtualKeyItem>();
		for (int i = 13; i <= 24; i++)
		{
			byte b = (byte)(112 + i - 1);
			list.Add(new VirtualKeyItem
			{
				Name = $"F{i} (虚拟键 0x{b:X2})",
				VirtualKey = b
			});
		}
		for (int j = 1; j <= 12; j++)
		{
			byte virtualKey = (byte)(111 + j);
			list.Add(new VirtualKeyItem
			{
				Name = $"F{j}",
				VirtualKey = virtualKey
			});
		}
		CmbVirtualKeys.ItemsSource = list;
	}

	private void LoadConfigToUi()
	{
		_isUpdatingUi = true;
		try
		{
			ChkCtrl.IsChecked = ResultConfig.Ctrl;
			ChkShift.IsChecked = ResultConfig.Shift;
			ChkAlt.IsChecked = ResultConfig.Alt;
			ChkWin.IsChecked = ResultConfig.Win;
			if (CmbVirtualKeys.ItemsSource is List<VirtualKeyItem> source)
			{
				VirtualKeyItem virtualKeyItem = source.FirstOrDefault((VirtualKeyItem x) => x.VirtualKey == ResultConfig.VirtualKey);
				if (virtualKeyItem != null)
				{
					CmbVirtualKeys.SelectedItem = virtualKeyItem;
				}
			}
			UpdatePreview();
		}
		finally
		{
			_isUpdatingUi = false;
		}
	}

	private void Modifier_Changed(object sender, RoutedEventArgs e)
	{
		if (!_isUpdatingUi)
		{
			ResultConfig.Ctrl = ChkCtrl.IsChecked.GetValueOrDefault();
			ResultConfig.Shift = ChkShift.IsChecked.GetValueOrDefault();
			ResultConfig.Alt = ChkAlt.IsChecked.GetValueOrDefault();
			ResultConfig.Win = ChkWin.IsChecked.GetValueOrDefault();
			UpdatePreview();
		}
	}

	private void CmbVirtualKeys_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		if (!_isUpdatingUi && CmbVirtualKeys.SelectedItem is VirtualKeyItem virtualKeyItem)
		{
			ResultConfig.VirtualKey = virtualKeyItem.VirtualKey;
			ResultConfig.Key = virtualKeyItem.Name.Split(' ')[0];
			UpdatePreview();
		}
	}

	private void CaptureBorder_PreviewKeyDown(object sender, KeyEventArgs e)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Invalid comparison between Unknown and I4
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Invalid comparison between Unknown and I4
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Invalid comparison between Unknown and I4
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		e.Handled = true;
		Key val = (e.Key == Key.System) ? e.SystemKey : e.Key;
		if (val == Key.LeftCtrl || val == Key.RightCtrl)
		{
			ChkCtrl.IsChecked = true;
			ResultConfig.Ctrl = true;
			UpdatePreview();
			return;
		}
		if (val == Key.LeftShift || val == Key.RightShift)
		{
			ChkShift.IsChecked = true;
			ResultConfig.Shift = true;
			UpdatePreview();
			return;
		}
		if (val == Key.LeftAlt || val == Key.RightAlt)
		{
			ChkAlt.IsChecked = true;
			ResultConfig.Alt = true;
			UpdatePreview();
			return;
		}
		if (val == Key.LWin || val == Key.RWin)
		{
			ChkWin.IsChecked = true;
			ResultConfig.Win = true;
			UpdatePreview();
			return;
		}
		byte vk = (byte)KeyInterop.VirtualKeyFromKey(val);
		ResultConfig.Key = val.ToString();
		ResultConfig.VirtualKey = vk;
		ResultConfig.Ctrl = Keyboard.Modifiers.HasFlag(ModifierKeys.Control) || ChkCtrl.IsChecked.GetValueOrDefault();
		ResultConfig.Shift = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) || ChkShift.IsChecked.GetValueOrDefault();
		ResultConfig.Alt = Keyboard.Modifiers.HasFlag(ModifierKeys.Alt) || ChkAlt.IsChecked.GetValueOrDefault();
		ResultConfig.Win = Keyboard.Modifiers.HasFlag(ModifierKeys.Windows) || ChkWin.IsChecked.GetValueOrDefault();
		_isUpdatingUi = true;
		try
		{
			ChkCtrl.IsChecked = ResultConfig.Ctrl;
			ChkShift.IsChecked = ResultConfig.Shift;
			ChkAlt.IsChecked = ResultConfig.Alt;
			ChkWin.IsChecked = ResultConfig.Win;
			if (CmbVirtualKeys.ItemsSource is List<VirtualKeyItem> source)
			{
				VirtualKeyItem selectedItem = source.FirstOrDefault((VirtualKeyItem x) => x.VirtualKey == vk);
				CmbVirtualKeys.SelectedItem = selectedItem;
			}
		}
		finally
		{
			_isUpdatingUi = false;
		}
		TxtCaptureHint.Text = "✅ 已捕获: " + ResultConfig.Key;
		UpdatePreview();
	}

	private void UpdatePreview()
	{
		TxtPreview.Text = ResultConfig.DisplayText;
	}

	private void Test_Click(object sender, RoutedEventArgs e)
	{
		if (HotkeySender.Send(ResultConfig))
		{
			MessageBox.Show(this, "按键模拟发送成功！\n已发送组合: " + ResultConfig.DisplayText, "测试结果", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
		else
		{
			MessageBox.Show(this, "按键发送失败，请查看日志！", "错误", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}
	}

	private void Ok_Click(object sender, RoutedEventArgs e)
	{
		if (ResultConfig.VirtualKey == 0)
		{
			MessageBox.Show(this, "请先选择或录入一个主功能按键！", "提示", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			return;
		}
		base.DialogResult = true;
		Close();
	}

	private void Cancel_Click(object sender, RoutedEventArgs e)
	{
		base.DialogResult = false;
		Close();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/GHelperGameModeAuto;component/views/hotkeyrecorddialog.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			TxtModeTitle = (TextBlock)target;
			break;
		case 2:
			TxtPreview = (TextBlock)target;
			break;
		case 3:
			((Button)target).Click += Test_Click;
			break;
		case 4:
			CaptureBorder = (Border)target;
			CaptureBorder.PreviewKeyDown += CaptureBorder_PreviewKeyDown;
			break;
		case 5:
			TxtCaptureHint = (TextBlock)target;
			break;
		case 6:
			ChkCtrl = (CheckBox)target;
			ChkCtrl.Checked += Modifier_Changed;
			ChkCtrl.Unchecked += Modifier_Changed;
			break;
		case 7:
			ChkShift = (CheckBox)target;
			ChkShift.Checked += Modifier_Changed;
			ChkShift.Unchecked += Modifier_Changed;
			break;
		case 8:
			ChkAlt = (CheckBox)target;
			ChkAlt.Checked += Modifier_Changed;
			ChkAlt.Unchecked += Modifier_Changed;
			break;
		case 9:
			ChkWin = (CheckBox)target;
			ChkWin.Checked += Modifier_Changed;
			ChkWin.Unchecked += Modifier_Changed;
			break;
		case 10:
			CmbVirtualKeys = (ComboBox)target;
			CmbVirtualKeys.SelectionChanged += CmbVirtualKeys_SelectionChanged;
			break;
		case 11:
			((Button)target).Click += Cancel_Click;
			break;
		case 12:
			((Button)target).Click += Ok_Click;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
