using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using GHelperGameModeAuto.Models;
using GHelperGameModeAuto.Services;

namespace GHelperGameModeAuto.Views;

public class ScanGamesDialog : Window, IComponentConnector
{
	private ObservableCollection<ScannedGame> _games = new ObservableCollection<ScannedGame>();

	internal Button BtnRescan;

	internal TextBlock TxtScanCount;

	internal ComboBox CmbBatchLaunchMode;

	internal ComboBox CmbBatchExitMode;

	internal DataGrid GridScannedGames;

	internal Border LoadingOverlay;

	internal TextBlock TxtSummary;

	internal Button BtnImport;

	private bool _contentLoaded;

	public List<GameConfig> ImportedGames { get; private set; } = new List<GameConfig>();


	private class BatchExitOption
	{
		public string Name { get; set; } = string.Empty;
		public ExitModeType ExitBehavior { get; set; }
		public GHelperMode FixedExitMode { get; set; }
	}

	private readonly List<BatchExitOption> _batchExitOptions = new List<BatchExitOption>();

	public ScanGamesDialog()
	{
		InitializeComponent();
		WindowHelper.ApplyDarkThemeAndIcon(this);
		var itemsSource = (from m in Enum.GetValues<GHelperMode>()
			select new
			{
				Mode = m,
				Name = m.ToDisplayName()
			}).ToList();
		CmbBatchLaunchMode.ItemsSource = itemsSource;
		CmbBatchLaunchMode.DisplayMemberPath = "Name";
		CmbBatchLaunchMode.SelectedValuePath = "Mode";
		CmbBatchLaunchMode.SelectedValue = GHelperMode.Turbo;
		_batchExitOptions.Add(new BatchExitOption
		{
			Name = "恢复启动前模式 (推荐)",
			ExitBehavior = ExitModeType.RestorePrevious,
			FixedExitMode = GHelperMode.Balanced
		});
		_batchExitOptions.Add(new BatchExitOption
		{
			Name = "固定为: 静音 (Silent)",
			ExitBehavior = ExitModeType.FixedMode,
			FixedExitMode = GHelperMode.Silent
		});
		_batchExitOptions.Add(new BatchExitOption
		{
			Name = "固定为: 平衡 (Balanced)",
			ExitBehavior = ExitModeType.FixedMode,
			FixedExitMode = GHelperMode.Balanced
		});
		_batchExitOptions.Add(new BatchExitOption
		{
			Name = "固定为: 增强 (Turbo)",
			ExitBehavior = ExitModeType.FixedMode,
			FixedExitMode = GHelperMode.Turbo
		});
		_batchExitOptions.Add(new BatchExitOption
		{
			Name = "固定为: 自定义 1 (Custom 1)",
			ExitBehavior = ExitModeType.FixedMode,
			FixedExitMode = GHelperMode.Custom1
		});
		_batchExitOptions.Add(new BatchExitOption
		{
			Name = "固定为: 自定义 2 (Custom 2)",
			ExitBehavior = ExitModeType.FixedMode,
			FixedExitMode = GHelperMode.Custom2
		});
		CmbBatchExitMode.ItemsSource = _batchExitOptions;
		CmbBatchExitMode.DisplayMemberPath = "Name";
		CmbBatchExitMode.SelectedIndex = 0;
		GridScannedGames.ItemsSource = _games;
		CleanUpHeaderUi();
		base.Loaded += async delegate
		{
			CleanUpHeaderUi();
			await DoScanAsync();
		};
	}

	private void CleanUpHeaderUi()
	{
		try
		{
			CmbBatchExitMode.Width = 185;
			foreach (TextBlock tb in WindowHelper.FindLogicalChildren<TextBlock>(this))
			{
				if (tb.Text != null && (tb.Text.Contains("扫描本机已安装") || tb.Text.Contains("Steam、Epic Games") || tb.Text.Contains("Steam 游戏") || tb.Text.Contains("Xbox 游戏")))
				{
					tb.Visibility = Visibility.Collapsed;
					tb.Height = 0;
					tb.Text = "";
				}
				else if (tb.Text != null && tb.Text.Contains("扫描已安装游戏"))
				{
					tb.Margin = new Thickness(0, 0, 0, 14);
				}
			}
		}
		catch
		{
		}
	}

	private async Task DoScanAsync()
	{
		LoadingOverlay.Visibility = Visibility.Visible;
		BtnRescan.IsEnabled = false;
		BtnImport.IsEnabled = false;
		TxtScanCount.Text = "扫描中...";
		try
		{
			List<ScannedGame> obj = await GameScannerService.ScanAllAsync();
			_games.Clear();
			foreach (ScannedGame item in obj)
			{
				_games.Add(item);
			}
			TxtScanCount.Text = $"共检索到 {_games.Count} 款游戏";
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, "扫描游戏异常: " + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
		finally
		{
			LoadingOverlay.Visibility = Visibility.Collapsed;
			BtnRescan.IsEnabled = true;
			BtnImport.IsEnabled = true;
		}
	}

	private async void Rescan_Click(object sender, RoutedEventArgs e)
	{
		await DoScanAsync();
	}

	private void SelectAll_Click(object sender, RoutedEventArgs e)
	{
		foreach (ScannedGame game in _games)
		{
			game.IsSelected = true;
		}
		GridScannedGames.Items.Refresh();
	}

	private void DeselectAll_Click(object sender, RoutedEventArgs e)
	{
		foreach (ScannedGame game in _games)
		{
			game.IsSelected = false;
		}
		GridScannedGames.Items.Refresh();
	}

	private void Import_Click(object sender, RoutedEventArgs e)
	{
		List<ScannedGame> list = _games.Where((ScannedGame g) => g.IsSelected).ToList();
		if (list.Count == 0)
		{
			MessageBox.Show(this, "请先勾选需要导入的游戏！", "提示", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		GHelperMode launchMode = (GHelperMode)(CmbBatchLaunchMode.SelectedValue ?? ((object)GHelperMode.Turbo));
		BatchExitOption selectedExit = (CmbBatchExitMode.SelectedItem as BatchExitOption) ?? _batchExitOptions[0];
		ImportedGames.Clear();
		foreach (ScannedGame item in list)
		{
			GameConfig gameConfig = item.ToGameConfig();
			gameConfig.LaunchMode = launchMode;
			gameConfig.ExitBehavior = selectedExit.ExitBehavior;
			gameConfig.FixedExitMode = selectedExit.FixedExitMode;
			ImportedGames.Add(gameConfig);
		}
		base.DialogResult = true;
		Close();
	}

	private void Cancel_Click(object sender, RoutedEventArgs e)
	{
		base.DialogResult = false;
		Close();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/GHelperGameModeAuto;component/views/scangamesdialog.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			BtnRescan = (Button)target;
			BtnRescan.Click += Rescan_Click;
			break;
		case 2:
			((Button)target).Click += SelectAll_Click;
			break;
		case 3:
			((Button)target).Click += DeselectAll_Click;
			break;
		case 4:
			TxtScanCount = (TextBlock)target;
			break;
		case 5:
			CmbBatchLaunchMode = (ComboBox)target;
			break;
		case 6:
			CmbBatchExitMode = (ComboBox)target;
			break;
		case 7:
			GridScannedGames = (DataGrid)target;
			break;
		case 8:
			LoadingOverlay = (Border)target;
			break;
		case 9:
			TxtSummary = (TextBlock)target;
			break;
		case 10:
			((Button)target).Click += Cancel_Click;
			break;
		case 11:
			BtnImport = (Button)target;
			BtnImport.Click += Import_Click;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
