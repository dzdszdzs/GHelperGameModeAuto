using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GHelperGameModeAuto.Services;

public static class WindowHelper
{
	[DllImport("dwmapi.dll", PreserveSig = true)]
	private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool DestroyIcon(IntPtr hIcon);

	private const int DWMWA_USE_IMMERSIVE_DARK_MODE_BEFORE_20H1 = 19;
	private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
	private const int DWMWA_CAPTION_COLOR = 35;
	private const int DWMWA_TEXT_COLOR = 36;

	private static ImageSource? _cachedImageSource;
	private static Icon? _cachedIcon;
	private static readonly object _iconLock = new object();

	public static void ApplyDarkThemeAndIcon(Window window)
	{
		try
		{
			if (window.Icon == null)
			{
				window.Icon = GetAppIconImageSource();
			}
		}
		catch
		{
		}

		Action applyDwm = () =>
		{
			try
			{
				IntPtr hwnd = new WindowInteropHelper(window).Handle;
				if (hwnd == IntPtr.Zero)
				{
					return;
				}

				int useDarkMode = 1;
				if (DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, ref useDarkMode, sizeof(int)) != 0)
				{
					DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE_BEFORE_20H1, ref useDarkMode, sizeof(int));
				}

				// Dark caption background #18181B (COLORREF 0x00BBGGRR -> 0x001B1818)
				int captionColor = 0x001B1818;
				DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ref captionColor, sizeof(int));

				// Light caption text #FAFAFA (COLORREF 0x00FAFAFA)
				int textColor = 0x00FAFAFA;
				DwmSetWindowAttribute(hwnd, DWMWA_TEXT_COLOR, ref textColor, sizeof(int));
			}
			catch
			{
			}
		};

		if (new WindowInteropHelper(window).Handle != IntPtr.Zero)
		{
			applyDwm();
		}
		else
		{
			window.SourceInitialized += delegate
			{
				applyDwm();
			};
		}
	}

	public static Icon GetAppIcon()
	{
		lock (_iconLock)
		{
			if (_cachedIcon != null)
			{
				return _cachedIcon;
			}

			try
			{
				string icoPath = Path.Combine(AppContext.BaseDirectory, "app.ico");
				if (File.Exists(icoPath))
				{
					_cachedIcon = new Icon(icoPath);
					return _cachedIcon;
				}
			}
			catch
			{
			}

			_cachedIcon = CreateApplicationIcon();
			return _cachedIcon;
		}
	}

	public static ImageSource? GetAppIconImageSource()
	{
		lock (_iconLock)
		{
			if (_cachedImageSource != null)
			{
				return _cachedImageSource;
			}

			try
			{
				Icon icon = GetAppIcon();
				_cachedImageSource = Imaging.CreateBitmapSourceFromHIcon(
					icon.Handle,
					Int32Rect.Empty,
					BitmapSizeOptions.FromEmptyOptions());
				_cachedImageSource.Freeze();
				return _cachedImageSource;
			}
			catch
			{
				return null;
			}
		}
	}

	public static Icon CreateApplicationIcon()
	{
		using Bitmap bitmap = new Bitmap(32, 32);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.Clear(System.Drawing.Color.Transparent);
			using System.Drawing.Drawing2D.LinearGradientBrush brush = new System.Drawing.Drawing2D.LinearGradientBrush(
				new Rectangle(0, 0, 32, 32),
				System.Drawing.Color.FromArgb(20, 184, 166),
				System.Drawing.Color.FromArgb(14, 116, 144),
				LinearGradientMode.ForwardDiagonal);
			graphics.FillEllipse(brush, 2, 2, 28, 28);
			System.Drawing.Point[] points = new System.Drawing.Point[7]
			{
				new System.Drawing.Point(18, 6),
				new System.Drawing.Point(11, 17),
				new System.Drawing.Point(16, 17),
				new System.Drawing.Point(13, 26),
				new System.Drawing.Point(22, 14),
				new System.Drawing.Point(17, 14),
				new System.Drawing.Point(20, 6)
			};
			using System.Drawing.SolidBrush brush2 = new System.Drawing.SolidBrush(System.Drawing.Color.White);
			graphics.FillPolygon(brush2, points);
		}
		IntPtr hIcon = bitmap.GetHicon();
		Icon icon = (Icon)Icon.FromHandle(hIcon).Clone();
		DestroyIcon(hIcon);
		return icon;
	}

	public static System.Collections.Generic.IEnumerable<T> FindLogicalChildren<T>(DependencyObject parent) where T : DependencyObject
	{
		if (parent == null)
		{
			yield break;
		}
		foreach (object child in LogicalTreeHelper.GetChildren(parent))
		{
			if (child is DependencyObject dep)
			{
				if (dep is T typed)
				{
					yield return typed;
				}
				foreach (T grandChild in FindLogicalChildren<T>(dep))
				{
					yield return grandChild;
				}
			}
		}
	}
}
