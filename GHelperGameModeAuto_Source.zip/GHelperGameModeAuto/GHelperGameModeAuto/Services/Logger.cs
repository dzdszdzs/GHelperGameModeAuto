using System;
using System.IO;

namespace GHelperGameModeAuto.Services;

public static class Logger
{
	private static readonly object _lock;

	private static readonly string _logDir;

	private static readonly string _logFilePath;

	private const long MaxLogSizeBytes = 5242880L;

	public static string LogFilePath => _logFilePath;

	public static string LogDirectory => _logDir;

	public static event Action<string>? LogAdded;

	static Logger()
	{
		_lock = new object();
		_logDir = Path.Combine(AppContext.BaseDirectory, "logs");
		_logFilePath = Path.Combine(_logDir, "GHelperGameModeAuto.log");
		try
		{
			if (!Directory.Exists(_logDir))
			{
				Directory.CreateDirectory(_logDir);
			}
		}
		catch
		{
		}
	}

	public static void Info(string message)
	{
		Write("INFO", message);
	}

	public static void Warn(string message)
	{
		Write("WARN", message);
	}

	public static void Error(string message, Exception? ex = null)
	{
		string message2 = ((ex != null) ? $"{message} | 异常: {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}" : message);
		Write("ERROR", message2);
	}

	public static void Debug(string message)
	{
		Write("DEBUG", message);
	}

	private static void Write(string level, string message)
	{
		string value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
		string text = $"[{value}] [{level}] {message}";
		try
		{
			lock (_lock)
			{
				if (!Directory.Exists(_logDir))
				{
					Directory.CreateDirectory(_logDir);
				}
				if (File.Exists(_logFilePath) && new FileInfo(_logFilePath).Length > 5242880)
				{
					string destFileName = Path.Combine(_logDir, $"GHelperGameModeAuto.{DateTime.Now:yyyyMMdd_HHmmss}.log");
					File.Move(_logFilePath, destFileName, overwrite: true);
				}
				File.AppendAllText(_logFilePath, text + Environment.NewLine);
			}
		}
		catch
		{
		}
		try
		{
			Logger.LogAdded?.Invoke(text);
		}
		catch
		{
		}
	}
}
