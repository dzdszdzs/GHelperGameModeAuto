using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace GHelperGameModeAuto.Services;

public static class GameScannerService
{
	private static readonly HashSet<string> IgnoredExeNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"UnityCrashHandler32.exe", "UnityCrashHandler64.exe", "CrashReportClient.exe", "dxwebsetup.exe", "unins000.exe", "uninstall.exe", "setup.exe", "vc_redist.x64.exe", "vc_redist.x86.exe", "vcredist_x64.exe",
		"vcredist_x86.exe", "vulkan-runtime.exe", "dotnetfx35.exe", "install.exe", "UE4PrereqSetup_x64.exe", "EasyAntiCheat_Setup.exe"
	};

	public static string NormalizePath(string path)
	{
		if (string.IsNullOrWhiteSpace(path))
		{
			return string.Empty;
		}
		try
		{
			string path2 = path.Replace('/', '\\');
			path2 = Path.GetFullPath(path2);
			if (path2.Length >= 2 && path2[1] == ':')
			{
				char reference = char.ToUpperInvariant(path2[0]);
				path2 = string.Concat(new ReadOnlySpan<char>(ref reference), path2.Substring(1));
			}
			return path2.TrimEnd('\\');
		}
		catch
		{
			string text = path.Replace('/', '\\').TrimEnd('\\');
			if (text.Length >= 2 && text[1] == ':')
			{
				char reference = char.ToUpperInvariant(text[0]);
				text = string.Concat(new ReadOnlySpan<char>(ref reference), text.Substring(1));
			}
			return text;
		}
	}

	public static async Task<List<ScannedGame>> ScanAllAsync()
	{
		return await Task.Run(delegate
		{
			List<ScannedGame> list = new List<ScannedGame>();
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			try
			{
				foreach (ScannedGame item4 in ScanSteamGames())
				{
					string item = (item4.ExecutablePath = NormalizePath(item4.ExecutablePath));
					if (hashSet.Add(item))
					{
						list.Add(item4);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("扫描 Steam 游戏异常", ex);
			}
			try
			{
				foreach (ScannedGame item5 in ScanEpicGames())
				{
					string item2 = (item5.ExecutablePath = NormalizePath(item5.ExecutablePath));
					if (hashSet.Add(item2))
					{
						list.Add(item5);
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("扫描 Epic Games 异常", ex2);
			}
			try
			{
				foreach (ScannedGame item6 in ScanXboxGames())
				{
					string item3 = (item6.ExecutablePath = NormalizePath(item6.ExecutablePath));
					if (hashSet.Add(item3))
					{
						list.Add(item6);
					}
				}
			}
			catch (Exception ex3)
			{
				Logger.Error("扫描 Xbox 游戏异常", ex3);
			}
			return list.OrderBy((ScannedGame x) => x.Name).ToList();
		});
	}

	public static List<ScannedGame> ScanSteamGames()
	{
		List<ScannedGame> list = new List<ScannedGame>();
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		string text = null;
		try
		{
			using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Valve\\Steam");
			text = registryKey?.GetValue("SteamPath") as string;
		}
		catch
		{
		}
		if (string.IsNullOrEmpty(text))
		{
			text = "C:\\Program Files (x86)\\Steam";
		}
		text = NormalizePath(text);
		if (!Directory.Exists(text))
		{
			return list;
		}
		HashSet<string> hashSet2 = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { text };
		string path = Path.Combine(text, "steamapps", "libraryfolders.vdf");
		if (File.Exists(path))
		{
			try
			{
				foreach (Match item in Regex.Matches(File.ReadAllText(path), "\"path\"\\s*\"([^\"]+)\""))
				{
					string text2 = NormalizePath(item.Groups[1].Value.Replace("\\\\", "\\"));
					if (Directory.Exists(text2))
					{
						hashSet2.Add(text2);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warn("解析 Steam libraryfolders.vdf 异常: " + ex.Message);
			}
		}
		foreach (string item2 in hashSet2)
		{
			string text3 = Path.Combine(item2, "steamapps");
			if (!Directory.Exists(text3))
			{
				continue;
			}
			string[] files = Directory.GetFiles(text3, "appmanifest_*.acf");
			foreach (string path2 in files)
			{
				try
				{
					string input = File.ReadAllText(path2);
					Match match = Regex.Match(input, "\"name\"\\s*\"([^\"]+)\"");
					Match match2 = Regex.Match(input, "\"installdir\"\\s*\"([^\"]+)\"");
					if (!match.Success || !match2.Success)
					{
						continue;
					}
					string value = match.Groups[1].Value;
					string value2 = match2.Groups[1].Value;
					if (value.StartsWith("Steamworks", StringComparison.OrdinalIgnoreCase) || value.StartsWith("Proton", StringComparison.OrdinalIgnoreCase))
					{
						continue;
					}
					string text4 = Path.Combine(text3, "common", value2);
					if (!Directory.Exists(text4))
					{
						continue;
					}
					string text5 = FindBestMainExecutable(text4, value2);
					if (text5 != null && File.Exists(text5))
					{
						string text6 = NormalizePath(text5);
						if (hashSet.Add(text6))
						{
							list.Add(new ScannedGame
							{
								Name = value,
								ProcessName = Path.GetFileNameWithoutExtension(text6),
								ExecutablePath = text6,
								Platform = "Steam"
							});
						}
					}
				}
				catch
				{
				}
			}
		}
		return list;
	}

	public static List<ScannedGame> ScanEpicGames()
	{
		List<ScannedGame> list = new List<ScannedGame>();
		string path = "C:\\ProgramData\\Epic\\EpicGamesLauncher\\Data\\Manifests";
		if (!Directory.Exists(path))
		{
			return list;
		}
		string[] files = Directory.GetFiles(path, "*.item");
		foreach (string path2 in files)
		{
			try
			{
				using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(path2));
				JsonElement rootElement = jsonDocument.RootElement;
				if (!rootElement.TryGetProperty("DisplayName", out var value) || !rootElement.TryGetProperty("InstallLocation", out var value2) || !rootElement.TryGetProperty("LaunchExecutable", out var value3))
				{
					continue;
				}
				string @string = value.GetString();
				string string2 = value2.GetString();
				string string3 = value3.GetString();
				if (!string.IsNullOrEmpty(@string) && !string.IsNullOrEmpty(string2) && !string.IsNullOrEmpty(string3))
				{
					string path3 = Path.Combine(string2, string3);
					if (File.Exists(path3))
					{
						string text = NormalizePath(path3);
						list.Add(new ScannedGame
						{
							Name = @string,
							ProcessName = Path.GetFileNameWithoutExtension(text),
							ExecutablePath = text,
							Platform = "Epic Games"
						});
					}
				}
			}
			catch
			{
			}
		}
		return list;
	}

	public static List<ScannedGame> ScanXboxGames()
	{
		List<ScannedGame> list = new List<ScannedGame>();
		foreach (DriveInfo item in from d in DriveInfo.GetDrives()
			where d.IsReady && d.DriveType == DriveType.Fixed
			select d)
		{
			string text = Path.Combine(item.RootDirectory.FullName, "XboxGames");
			if (!Directory.Exists(text))
			{
				continue;
			}
			try
			{
				string[] directories = Directory.GetDirectories(text);
				foreach (string text2 in directories)
				{
					string fileName = Path.GetFileName(text2);
					string text3 = Path.Combine(text2, "Content");
					string text4 = (Directory.Exists(text3) ? text3 : text2);
					string text5 = null;
					string text6 = null;
					string path = Path.Combine(text4, "MicrosoftGame.config");
					if (File.Exists(path))
					{
						try
						{
							Match match = Regex.Match(File.ReadAllText(path), "Executable=\"([^\"]+)\"");
							if (match.Success)
							{
								text6 = Path.Combine(text4, match.Groups[1].Value);
							}
						}
						catch
						{
						}
					}
					if (text6 == null || !File.Exists(text6))
					{
						text6 = FindBestMainExecutable(text4, fileName);
					}
					if (text6 != null && File.Exists(text6))
					{
						string text7 = NormalizePath(text6);
						list.Add(new ScannedGame
						{
							Name = (text5 ?? fileName),
							ProcessName = Path.GetFileNameWithoutExtension(text7),
							ExecutablePath = text7,
							Platform = "Xbox"
						});
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warn("扫描 Xbox 目录 " + text + " 异常: " + ex.Message);
			}
		}
		return list;
	}

	private static string? FindBestMainExecutable(string rootDir, string hintName)
	{
		string hintName2 = hintName;
		try
		{
			List<string> list = (from f in Directory.GetFiles(rootDir, "*.exe", SearchOption.TopDirectoryOnly)
				where !IgnoredExeNames.Contains(Path.GetFileName(f))
				select f).ToList();
			if (list.Count == 0)
			{
				string[] array = new string[4] { "Binaries\\Win64", "bin\\x64", "bin", "game" };
				foreach (string path in array)
				{
					string path2 = Path.Combine(rootDir, path);
					if (Directory.Exists(path2))
					{
						List<string> list2 = (from f in Directory.GetFiles(path2, "*.exe", SearchOption.TopDirectoryOnly)
							where !IgnoredExeNames.Contains(Path.GetFileName(f))
							select f).ToList();
						if (list2.Count > 0)
						{
							list.AddRange(list2);
							break;
						}
					}
				}
			}
			if (list.Count == 0)
			{
				return null;
			}
			string text = list.FirstOrDefault((string f) => Path.GetFileNameWithoutExtension(f).Equals(hintName2, StringComparison.OrdinalIgnoreCase));
			if (text != null)
			{
				return text;
			}
			string text2 = list.FirstOrDefault((string f) => hintName2.Contains(Path.GetFileNameWithoutExtension(f), StringComparison.OrdinalIgnoreCase) || Path.GetFileNameWithoutExtension(f).Contains(hintName2, StringComparison.OrdinalIgnoreCase));
			if (text2 != null)
			{
				return text2;
			}
			return list.OrderByDescending(delegate(string f)
			{
				try
				{
					return new FileInfo(f).Length;
				}
				catch
				{
					return 0L;
				}
			}).FirstOrDefault();
		}
		catch
		{
			return null;
		}
	}
}
