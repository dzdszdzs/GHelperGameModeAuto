using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace GHelperGameModeAuto.Services;

public static class MemoryOptimizer
{
	private static readonly object _lock = new object();

	private static DateTime _lastTrimTime = DateTime.MinValue;

	[DllImport("psapi.dll")]
	private static extern int EmptyWorkingSet(nint hwProc);

	[DllImport("kernel32.dll")]
	private static extern bool SetProcessWorkingSetSize(nint proc, nint min, nint max);

	public static void TrimMemory()
	{
		lock (_lock)
		{
			if ((DateTime.Now - _lastTrimTime).TotalSeconds < 5.0)
			{
				return;
			}
			_lastTrimTime = DateTime.Now;
			try
			{
				GC.Collect(2, GCCollectionMode.Optimized);
				nint handle = Process.GetCurrentProcess().Handle;
				EmptyWorkingSet(handle);
				SetProcessWorkingSetSize(handle, -1, -1);
				Logger.Debug("已完成后台工作集优化");
			}
			catch (Exception ex)
			{
				Logger.Debug("修剪内存异常 (非致命): " + ex.Message);
			}
		}
	}
}
