using System;
using System.IO;

namespace GHelperGameModeAuto.Services;

public static class AutoStartService
{
	private const string ShortcutFileName = "GHelperGameModeAuto.lnk";

	private static string GetStartupShortcutPath()
	{
		return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "GHelperGameModeAuto.lnk");
	}

	private static string GetExecutablePath()
	{
		string text = Environment.ProcessPath;
		if (string.IsNullOrEmpty(text))
		{
			text = Path.Combine(AppContext.BaseDirectory, "GHelperGameModeAuto.exe");
		}
		return text;
	}

	public static bool IsAutoStartEnabled()
	{
		return File.Exists(GetStartupShortcutPath());
	}

	public static bool SetAutoStart(bool enable)
	{
		string startupShortcutPath = GetStartupShortcutPath();
		try
		{
			if (enable)
			{
				string executablePath = GetExecutablePath();
				string baseDirectory = AppContext.BaseDirectory;
				Type typeFromProgID = Type.GetTypeFromProgID("WScript.Shell");
				if (typeFromProgID == null)
				{
					Logger.Error("无法获取 WScript.Shell COM 对象，创建自启动快捷方式失败");
					return false;
				}
				dynamic val = Activator.CreateInstance(typeFromProgID);
				dynamic val2 = val.CreateShortcut(startupShortcutPath);
				val2.TargetPath = executablePath;
				val2.Arguments = "--minimized";
				val2.WorkingDirectory = baseDirectory;
				val2.Description = "G-Helper Game Mode Auto Switcher";
				val2.Save();
				Logger.Info("已创建开机自启快捷方式: " + startupShortcutPath);
				return true;
			}
			if (File.Exists(startupShortcutPath))
			{
				File.Delete(startupShortcutPath);
				Logger.Info("已移除开机自启快捷方式: " + startupShortcutPath);
			}
			return true;
		}
		catch (Exception ex)
		{
			Logger.Error($"修改自启动状态失败 (enable={enable})", ex);
			return false;
		}
	}
}
