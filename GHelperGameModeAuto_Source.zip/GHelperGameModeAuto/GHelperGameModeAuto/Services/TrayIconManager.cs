using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using GHelperGameModeAuto.Models;

namespace GHelperGameModeAuto.Services;

public class TrayIconManager : IDisposable
{
	private readonly NotifyIcon _notifyIcon;

	private readonly ProcessMonitorService _monitorService;

	private readonly ConfigService _configService;

	private readonly Action _showMainWindowAction;

	private readonly Action _exitAppAction;

	private ToolStripMenuItem _statusItem;

	private ToolStripMenuItem _pauseItem;

	private ToolStripMenuItem _autoStartItem;

	public TrayIconManager(ProcessMonitorService monitorService, ConfigService configService, Action showMainWindowAction, Action exitAppAction)
	{
		_monitorService = monitorService;
		_configService = configService;
		_showMainWindowAction = showMainWindowAction;
		_exitAppAction = exitAppAction;
		_notifyIcon = new NotifyIcon
		{
			Icon = WindowHelper.GetAppIcon(),
			Text = "G-Helper 游戏模式自动切换",
			Visible = true
		};
		BuildContextMenu();
		_notifyIcon.DoubleClick += delegate
		{
			_showMainWindowAction();
		};
		_monitorService.ModeChanged += delegate
		{
			UpdateTrayTooltip();
		};
		_monitorService.ActiveGameChanged += delegate
		{
			UpdateTrayTooltip();
		};
		_monitorService.PauseStateChanged += delegate(bool paused)
		{
			UpdateTrayState(paused);
		};
		UpdateTrayTooltip();
	}

	private void BuildContextMenu()
	{
		ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
		_statusItem = new ToolStripMenuItem("状态: 运行中")
		{
			Enabled = false
		};
		contextMenuStrip.Items.Add(_statusItem);
		contextMenuStrip.Items.Add(new ToolStripSeparator());
		_pauseItem = new ToolStripMenuItem(_monitorService.IsPaused ? "▶ 恢复自动切换" : "⏸ 暂停自动切换");
		_pauseItem.Click += delegate
		{
			_monitorService.SetPaused(!_monitorService.IsPaused);
		};
		contextMenuStrip.Items.Add(_pauseItem);
		ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem("⚡ 手动切换模式");
		foreach (GHelperMode value in Enum.GetValues(typeof(GHelperMode)))
		{
			GHelperMode targetMode = value;
			ToolStripMenuItem toolStripMenuItem2 = new ToolStripMenuItem(targetMode.ToDisplayName());
			toolStripMenuItem2.Click += delegate
			{
				_monitorService.ManualSwitchMode(targetMode);
			};
			toolStripMenuItem.DropDownItems.Add(toolStripMenuItem2);
		}
		contextMenuStrip.Items.Add(toolStripMenuItem);
		contextMenuStrip.Items.Add(new ToolStripSeparator());
		ToolStripMenuItem toolStripMenuItem3 = new ToolStripMenuItem("⚙ 打开主界面");
		toolStripMenuItem3.Font = new Font(toolStripMenuItem3.Font, FontStyle.Bold);
		toolStripMenuItem3.Click += delegate
		{
			_showMainWindowAction();
		};
		contextMenuStrip.Items.Add(toolStripMenuItem3);
		_autoStartItem = new ToolStripMenuItem("开机自启动")
		{
			Checked = AutoStartService.IsAutoStartEnabled()
		};
		_autoStartItem.Click += delegate
		{
			bool flag = !_autoStartItem.Checked;
			if (AutoStartService.SetAutoStart(flag))
			{
				_autoStartItem.Checked = flag;
				_configService.Current.AutoStart = flag;
				_configService.Save();
			}
		};
		contextMenuStrip.Items.Add(_autoStartItem);
		ToolStripMenuItem toolStripMenuItem4 = new ToolStripMenuItem("\ud83d\udcc4 打开日志文件");
		toolStripMenuItem4.Click += delegate
		{
			try
			{
				if (File.Exists(Logger.LogFilePath))
				{
					Process.Start(new ProcessStartInfo
					{
						FileName = Logger.LogFilePath,
						UseShellExecute = true
					});
				}
				else
				{
					Process.Start(new ProcessStartInfo
					{
						FileName = Logger.LogDirectory,
						UseShellExecute = true
					});
				}
			}
			catch
			{
			}
		};
		contextMenuStrip.Items.Add(toolStripMenuItem4);
		contextMenuStrip.Items.Add(new ToolStripSeparator());
		ToolStripMenuItem toolStripMenuItem5 = new ToolStripMenuItem("❌ 退出程序");
		toolStripMenuItem5.Click += delegate
		{
			_exitAppAction();
		};
		contextMenuStrip.Items.Add(toolStripMenuItem5);
		_notifyIcon.ContextMenuStrip = contextMenuStrip;
	}

	private void UpdateTrayState(bool isPaused)
	{
		_pauseItem.Text = (isPaused ? "▶ 恢复自动切换" : "⏸ 暂停自动切换");
		UpdateTrayTooltip();
	}

	private void UpdateTrayTooltip()
	{
		string value = _monitorService.CurrentMode.ToShortName();
		string value2 = ((_monitorService.ActiveGame != null) ? ("[" + _monitorService.ActiveGame.Name + "]") : "无游戏");
		string value3 = (_monitorService.IsPaused ? "(已暂停)" : "(运行中)");
		_statusItem.Text = $"模式: {value} | 游戏: {value2} {value3}";
		string text = $"G-Helper 自动切换: {value}\n当前游戏: {value2}\n状态: {(_monitorService.IsPaused ? "已暂停" : "监控中")}";
		if (text.Length >= 64)
		{
			text = text.Substring(0, 60) + "...";
		}
		_notifyIcon.Text = text;
	}

	public void ShowNotification(string title, string message, ToolTipIcon icon = ToolTipIcon.Info)
	{
		_notifyIcon.ShowBalloonTip(3000, title, message, icon);
	}

	private static Icon CreateApplicationIcon()
	{
		using Bitmap bitmap = new Bitmap(32, 32);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.Clear(Color.Transparent);
			using LinearGradientBrush brush = new LinearGradientBrush(new Rectangle(0, 0, 32, 32), Color.FromArgb(20, 184, 166), Color.FromArgb(14, 116, 144), LinearGradientMode.ForwardDiagonal);
			graphics.FillEllipse(brush, 2, 2, 28, 28);
			Point[] points = new Point[7]
			{
				new Point(18, 6),
				new Point(11, 17),
				new Point(16, 17),
				new Point(13, 26),
				new Point(22, 14),
				new Point(17, 14),
				new Point(20, 6)
			};
			using SolidBrush brush2 = new SolidBrush(Color.White);
			graphics.FillPolygon(brush2, points);
		}
		return Icon.FromHandle(bitmap.GetHicon());
	}

	public void Dispose()
	{
		_notifyIcon.Visible = false;
		_notifyIcon.Dispose();
	}
}
