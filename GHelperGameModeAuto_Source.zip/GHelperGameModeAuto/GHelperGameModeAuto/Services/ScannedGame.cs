using System;
using GHelperGameModeAuto.Models;

namespace GHelperGameModeAuto.Services;

public class ScannedGame
{
	public string Name { get; set; } = string.Empty;


	public string ProcessName { get; set; } = string.Empty;


	public string ExecutablePath { get; set; } = string.Empty;


	public string Platform { get; set; } = "Steam";


	public bool IsSelected { get; set; } = true;


	public GHelperMode LaunchMode { get; set; } = GHelperMode.Turbo;


	public ExitModeType ExitBehavior { get; set; }

	public GHelperMode FixedExitMode { get; set; } = GHelperMode.Balanced;


	public GameConfig ToGameConfig()
	{
		return new GameConfig
		{
			Id = Guid.NewGuid().ToString("N"),
			Name = Name,
			ProcessName = ProcessName,
			ExecutablePath = ExecutablePath,
			LaunchMode = LaunchMode,
			ExitBehavior = ExitBehavior,
			FixedExitMode = FixedExitMode,
			IsEnabled = true,
			Platform = Platform
		};
	}
}
