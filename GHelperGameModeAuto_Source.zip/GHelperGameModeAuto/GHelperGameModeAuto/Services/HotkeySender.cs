using System;
using System.Runtime.InteropServices;
using System.Threading;
using GHelperGameModeAuto.Models;

namespace GHelperGameModeAuto.Services;

public static class HotkeySender
{
	private const uint KEYEVENTF_EXTENDEDKEY = 1u;

	private const uint KEYEVENTF_KEYUP = 2u;

	private const byte VK_CONTROL = 17;

	private const byte VK_SHIFT = 16;

	private const byte VK_MENU = 18;

	private const byte VK_LWIN = 91;

	[DllImport("user32.dll", SetLastError = true)]
	private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, nuint dwExtraInfo);

	public static bool Send(HotkeyConfig hotkey)
	{
		if (hotkey == null || hotkey.VirtualKey == 0)
		{
			Logger.Warn("尝试发送无效或未绑定的快捷键");
			return false;
		}
		try
		{
			Logger.Info($"[按键模拟] 发送快捷键组合: {hotkey.DisplayText} (VK: 0x{hotkey.VirtualKey:X2})");
			if (hotkey.Ctrl)
			{
				keybd_event(17, 0, 0u, UIntPtr.Zero);
			}
			if (hotkey.Shift)
			{
				keybd_event(16, 0, 0u, UIntPtr.Zero);
			}
			if (hotkey.Alt)
			{
				keybd_event(18, 0, 0u, UIntPtr.Zero);
			}
			if (hotkey.Win)
			{
				keybd_event(91, 0, 1u, UIntPtr.Zero);
			}
			uint num = 0u;
			if (IsExtendedKey(hotkey.VirtualKey))
			{
				num |= 1u;
			}
			keybd_event(hotkey.VirtualKey, 0, num, UIntPtr.Zero);
			Thread.Sleep(35);
			keybd_event(hotkey.VirtualKey, 0, num | 2u, UIntPtr.Zero);
			if (hotkey.Win)
			{
				keybd_event(91, 0, 3u, UIntPtr.Zero);
			}
			if (hotkey.Alt)
			{
				keybd_event(18, 0, 2u, UIntPtr.Zero);
			}
			if (hotkey.Shift)
			{
				keybd_event(16, 0, 2u, UIntPtr.Zero);
			}
			if (hotkey.Ctrl)
			{
				keybd_event(17, 0, 2u, UIntPtr.Zero);
			}
			return true;
		}
		catch (Exception ex)
		{
			Logger.Error("模拟发送按键失败: " + hotkey.DisplayText, ex);
			return false;
		}
	}

	private static bool IsExtendedKey(byte vk)
	{
		switch (vk)
		{
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
			return true;
		case 91:
		case 92:
		case 93:
			return true;
		default:
			return false;
		}
	}
}
