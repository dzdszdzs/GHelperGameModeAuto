using System;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using GHelperGameModeAuto.Models;

namespace GHelperGameModeAuto.Services;

public class ConfigService
{
	private static readonly object _fileLock = new object();

	private readonly string _configDir;

	private readonly string _configFilePath;

	private readonly JsonSerializerOptions _jsonOptions;

	public AppSettings Current { get; private set; }

	public string ConfigDirectory => _configDir;

	public string ConfigFilePath => _configFilePath;

	private int _configVersion;

	public int ConfigVersion => _configVersion;

	public event Action? ConfigSaved;

	public ConfigService()
	{
		_configDir = Path.Combine(AppContext.BaseDirectory, "config");
		_configFilePath = Path.Combine(_configDir, "settings.json");
		_jsonOptions = new JsonSerializerOptions
		{
			WriteIndented = true,
			Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
			PropertyNameCaseInsensitive = true,
			Converters = { (JsonConverter)new JsonStringEnumConverter() }
		};
		Current = LoadOrCreateDefault();
	}

	private AppSettings LoadOrCreateDefault()
	{
		lock (_fileLock)
		{
			try
			{
				if (!Directory.Exists(_configDir))
				{
					Directory.CreateDirectory(_configDir);
				}
				if (File.Exists(_configFilePath))
				{
					AppSettings appSettings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(_configFilePath), _jsonOptions);
					if (appSettings != null)
					{
						Logger.Info("已从本地配置文件加载设置: " + _configFilePath);
						return appSettings;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("读取配置文件失败，正在备份并创建默认配置", ex);
				try
				{
					string destFileName = Path.Combine(_configDir, $"settings.corrupted.{DateTime.Now:yyyyMMdd_HHmmss}.json");
					if (File.Exists(_configFilePath))
					{
						File.Move(_configFilePath, destFileName, overwrite: true);
					}
				}
				catch
				{
				}
			}
			AppSettings appSettings2 = new AppSettings();
			SaveInternal(appSettings2);
			Logger.Info("已在程序本地目录创建默认配置: " + _configFilePath);
			return appSettings2;
		}
	}

	public void Save()
	{
		lock (_fileLock)
		{
			SaveInternal(Current);
		}
	}

	private void SaveInternal(AppSettings settings)
	{
		try
		{
			if (!Directory.Exists(_configDir))
			{
				Directory.CreateDirectory(_configDir);
			}
			string contents = JsonSerializer.Serialize(settings, _jsonOptions);
			string text = _configFilePath + ".tmp";
			File.WriteAllText(text, contents);
			if (File.Exists(_configFilePath))
			{
				File.Replace(text, _configFilePath, null);
			}
			else
			{
				File.Move(text, _configFilePath);
			}
			Interlocked.Increment(ref _configVersion);
			Logger.Debug("配置文件已成功保存到本地");
			ConfigSaved?.Invoke();
		}
		catch (Exception ex)
		{
			Logger.Error("保存配置文件异常", ex);
		}
	}

	public void Reload()
	{
		Current = LoadOrCreateDefault();
		Interlocked.Increment(ref _configVersion);
		ConfigSaved?.Invoke();
	}
}
