using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using GHelperGameModeAuto.Models;

namespace GHelperGameModeAuto.Services;

public class ProcessMonitorService : IDisposable
{
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct PROCESSENTRY32
	{
		public uint dwSize;

		public uint cntUsage;

		public uint th32ProcessID;

		public nint th32DefaultHeapID;

		public uint th32ModuleID;

		public uint cntThreads;

		public uint th32ParentProcessID;

		public int pcPriClassBase;

		public uint dwFlags;

		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
		public string szExeFile;
	}

	private readonly ConfigService _configService;

	private readonly Timer _timer;

	private readonly object _lock = new object();

	private readonly object _indexLock = new object();

	private volatile bool _isDisposed;

	private volatile bool _isPaused;

	private int _isChecking; // 0 = idle, 1 = checking (thread-safe guard)

	private int _userInterval;

	private GHelperMode _currentMode;

	private GHelperMode _preGameMode;

	private GameConfig? _activeGame;

	private readonly HashSet<string> _currentlyRunningGameIds = new HashSet<string>();

	// Reusable cached collections to prevent allocations during scan
	private readonly Dictionary<string, List<GameConfig>> _gameProcessIndex = new Dictionary<string, List<GameConfig>>(StringComparer.OrdinalIgnoreCase);

	private int _lastIndexedVersion = -1;

	private readonly List<GameConfig> _detectedGames = new List<GameConfig>(8);

	private readonly HashSet<string> _detectedGameIds = new HashSet<string>(8);

	private const uint TH32CS_SNAPPROCESS = 2u;

	private static readonly nint INVALID_HANDLE_VALUE = new IntPtr(-1);

	public GHelperMode CurrentMode => _currentMode;

	public GHelperMode PreGameMode => _preGameMode;

	public GameConfig? ActiveGame => _activeGame;

	public bool IsPaused => _isPaused;

	public event Action<GHelperMode>? ModeChanged;

	public event Action<GameConfig?>? ActiveGameChanged;

	public event Action<bool>? PauseStateChanged;

	public event Action<string>? StatusMessageChanged;

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern nint CreateToolhelp32Snapshot(uint dwFlags, uint th32ProcessID);

	[DllImport("kernel32.dll", EntryPoint = "Process32FirstW", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool Process32First(nint hSnapshot, ref PROCESSENTRY32 lppe);

	[DllImport("kernel32.dll", EntryPoint = "Process32NextW", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool Process32Next(nint hSnapshot, ref PROCESSENTRY32 lppe);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool CloseHandle(nint hObject);

	public ProcessMonitorService(ConfigService configService)
	{
		_configService = configService;
		_currentMode = _configService.Current.DefaultBaselineMode;
		_preGameMode = _currentMode;
		_isPaused = _configService.Current.IsPaused;
		_userInterval = Math.Max(500, _configService.Current.PollingIntervalMs);

		_configService.ConfigSaved += OnConfigSaved;
		RebuildGameIndex();

		int initialInterval = _isPaused ? Timeout.Infinite : GetIdleInterval();
		_timer = new Timer(OnTimerTick, null, 1500, initialInterval);

		Logger.Info($"游戏监控服务已就绪，轮询间隔: 活跃={GetActiveInterval()}ms / 空闲={GetIdleInterval()}ms，初始基准模式: {_currentMode.ToDisplayName()}");
	}

	private void OnConfigSaved()
	{
		RebuildGameIndex();
	}

	public void InvalidateGameIndex()
	{
		RebuildGameIndex();
	}

	private void RebuildGameIndex()
	{
		lock (_indexLock)
		{
			_gameProcessIndex.Clear();
			List<GameConfig> games = _configService.Current.Games;
			if (games != null)
			{
				for (int i = 0; i < games.Count; i++)
				{
					GameConfig game = games[i];
					if (!game.IsEnabled)
					{
						continue;
					}
					string cleanName = game.CleanProcessName;
					if (string.IsNullOrEmpty(cleanName))
					{
						continue;
					}

					if (!_gameProcessIndex.TryGetValue(cleanName, out var list))
					{
						list = new List<GameConfig>(2);
						_gameProcessIndex[cleanName] = list;
					}
					list.Add(game);

					// Also index with .exe suffix so scan loop needs zero string manipulation
					string exeName = cleanName + ".exe";
					if (!_gameProcessIndex.ContainsKey(exeName))
					{
						_gameProcessIndex[exeName] = list; // Reuse identical list reference
					}
				}
			}
			_lastIndexedVersion = _configService.ConfigVersion;
		}
	}

	private int GetActiveInterval()
	{
		return Math.Max(500, _userInterval);
	}

	private int GetIdleInterval()
	{
		// Lower frequency when no target game is running to save background CPU
		int user = Math.Max(500, _userInterval);
		if (user < 2000)
		{
			return 3000;
		}
		return Math.Min((int)(user * 1.5), 6000);
	}

	private void ApplyCurrentInterval()
	{
		if (_isDisposed)
		{
			return;
		}
		if (_isPaused)
		{
			_timer.Change(Timeout.Infinite, Timeout.Infinite);
			return;
		}
		int targetInterval = (_activeGame != null) ? GetActiveInterval() : GetIdleInterval();
		_timer.Change(targetInterval, targetInterval);
	}

	public void SetPaused(bool paused)
	{
		lock (_lock)
		{
			if (_isPaused == paused)
			{
				return;
			}
			_isPaused = paused;
			_configService.Current.IsPaused = paused;
			_configService.Save();

			if (_isPaused)
			{
				_timer.Change(Timeout.Infinite, Timeout.Infinite);
			}
			else
			{
				ApplyCurrentInterval();
			}
		}
		Logger.Info(_isPaused ? "自动模式切换已暂停" : "自动模式切换已恢复");
		this.PauseStateChanged?.Invoke(_isPaused);
		this.StatusMessageChanged?.Invoke(_isPaused ? "监控已暂停" : "监控运行中");
		if (_isPaused)
		{
			MemoryOptimizer.TrimMemory();
		}
	}

	public void ManualSwitchMode(GHelperMode targetMode)
	{
		lock (_lock)
		{
			if (HotkeySender.Send(_configService.Current.GetHotkey(targetMode)))
			{
				_currentMode = targetMode;
				if (_activeGame == null)
				{
					_preGameMode = targetMode;
				}
				Logger.Info("[手动切换] G-Helper 模式已切换至: " + targetMode.ToDisplayName());
				this.ModeChanged?.Invoke(_currentMode);
			}
		}
	}

	public void CalibrateMode(GHelperMode mode)
	{
		lock (_lock)
		{
			_currentMode = mode;
			if (_activeGame == null)
			{
				_preGameMode = mode;
			}
			this.ModeChanged?.Invoke(_currentMode);
		}
	}

	public void UpdateInterval(int intervalMs)
	{
		_userInterval = Math.Max(500, intervalMs);
		ApplyCurrentInterval();
	}

	private void OnTimerTick(object? state)
	{
		if (_isDisposed || _isPaused)
		{
			return;
		}

		// Ensure thread-safe non-reentrant single execution
		if (Interlocked.CompareExchange(ref _isChecking, 1, 0) != 0)
		{
			return;
		}

		try
		{
			if (_isDisposed || _isPaused)
			{
				return;
			}
			CheckRunningProcessesFast();
		}
		catch (Exception ex)
		{
			Logger.Error("进程监控检查异常", ex);
		}
		finally
		{
			Interlocked.Exchange(ref _isChecking, 0);
		}
	}

	private void CheckRunningProcessesFast()
	{
		if (_lastIndexedVersion != _configService.ConfigVersion)
		{
			RebuildGameIndex();
		}

		if (_gameProcessIndex.Count == 0)
		{
			if (_activeGame != null)
			{
				lock (_lock)
				{
					_activeGame = null;
					_currentlyRunningGameIds.Clear();
					this.ActiveGameChanged?.Invoke(null);
					ApplyCurrentInterval();
				}
			}
			return;
		}

		_detectedGames.Clear();
		_detectedGameIds.Clear();

		nint hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0u);
		if (hSnapshot != INVALID_HANDLE_VALUE)
		{
			try
			{
				PROCESSENTRY32 lppe = default(PROCESSENTRY32);
				lppe.dwSize = (uint)Marshal.SizeOf<PROCESSENTRY32>();
				if (Process32First(hSnapshot, ref lppe))
				{
					do
					{
						string szExeFile = lppe.szExeFile;
						if (string.IsNullOrEmpty(szExeFile))
						{
							continue;
						}

						// Direct O(1) dictionary lookup on process name (matching both with and without .exe)
						if (_gameProcessIndex.TryGetValue(szExeFile, out var matchedGames))
						{
							for (int i = 0; i < matchedGames.Count; i++)
							{
								GameConfig game = matchedGames[i];
								if (_detectedGameIds.Add(game.Id))
								{
									_detectedGames.Add(game);
								}
							}
						}
					}
					while (Process32Next(hSnapshot, ref lppe));
				}
				else
				{
					int err = Marshal.GetLastWin32Error();
					Logger.Warn($"Process32First 扫描首个进程失败，错误代码: {err}");
				}
			}
			finally
			{
				CloseHandle(hSnapshot);
			}
		}

		lock (_lock)
		{
			if (_detectedGames.Count > 0)
			{
				// Check if there is any newly launched game not yet in _currentlyRunningGameIds
				GameConfig? newlyLaunchedGame = null;
				for (int i = 0; i < _detectedGames.Count; i++)
				{
					GameConfig g = _detectedGames[i];
					if (!_currentlyRunningGameIds.Contains(g.Id))
					{
						newlyLaunchedGame = g;
					}
				}

				if (newlyLaunchedGame != null)
				{
					if (_currentlyRunningGameIds.Count == 0)
					{
						_preGameMode = _currentMode;
						Logger.Info("[游戏启动] 检测到首个游戏运行: " + newlyLaunchedGame.Name + "，记录启动前基准模式为: " + _preGameMode.ToDisplayName());
					}
					else
					{
						Logger.Info("[多游戏并发] 检测到新游戏运行: " + newlyLaunchedGame.Name);
					}

					_activeGame = newlyLaunchedGame;
					_currentlyRunningGameIds.Clear();
					foreach (string id in _detectedGameIds)
					{
						_currentlyRunningGameIds.Add(id);
					}

					// Immediately switch timer to active game polling frequency
					ApplyCurrentInterval();

					TriggerModeSwitch(newlyLaunchedGame.LaunchMode, "游戏 [" + newlyLaunchedGame.Name + "] 启动");
					this.ActiveGameChanged?.Invoke(_activeGame);
				}
				else
				{
					// Games are already active, synchronize running IDs without allocation
					_currentlyRunningGameIds.Clear();
					foreach (string id in _detectedGameIds)
					{
						_currentlyRunningGameIds.Add(id);
					}
				}
			}
			else
			{
				if (_currentlyRunningGameIds.Count <= 0 && _activeGame == null)
				{
					return;
				}

				GameConfig? activeGame = _activeGame;
				Logger.Info("[游戏退出] 检测到游戏已退出: " + (activeGame?.Name ?? "未知"));
				_currentlyRunningGameIds.Clear();
				_activeGame = null;

				// Immediately revert timer to idle low-frequency polling
				ApplyCurrentInterval();

				this.ActiveGameChanged?.Invoke(null);
				if (activeGame != null)
				{
					if (activeGame.ExitBehavior == ExitModeType.RestorePrevious)
					{
						Logger.Info("[退出策略: 恢复模式] 正在恢复至启动前模式: " + _preGameMode.ToDisplayName());
						TriggerModeSwitch(_preGameMode, "恢复启动前模式 (" + _preGameMode.ToDisplayName() + ")");
					}
					else
					{
						Logger.Info("[退出策略: 固定模式] 正在切换至固定退出模式: " + activeGame.FixedExitMode.ToDisplayName());
						TriggerModeSwitch(activeGame.FixedExitMode, "固定退出模式 (" + activeGame.FixedExitMode.ToDisplayName() + ")");
					}
				}
			}
		}
	}

	private void TriggerModeSwitch(GHelperMode targetMode, string reason)
	{
		if (HotkeySender.Send(_configService.Current.GetHotkey(targetMode)))
		{
			_currentMode = targetMode;
			Logger.Info("[自动切换成功] 原因: " + reason + " -> 切换为: " + targetMode.ToDisplayName());
			this.ModeChanged?.Invoke(_currentMode);
			this.StatusMessageChanged?.Invoke($"已切换至 {targetMode.ToDisplayName()} ({reason})");
		}
		else
		{
			Logger.Warn("[自动切换失败] 无法发送按键以切换至 " + targetMode.ToDisplayName());
		}
	}

	public void Dispose()
	{
		if (!_isDisposed)
		{
			_isDisposed = true;
			try
			{
				_timer.Change(Timeout.Infinite, Timeout.Infinite);
				_timer.Dispose();
			}
			catch
			{
			}
			_configService.ConfigSaved -= OnConfigSaved;
		}
	}
}
