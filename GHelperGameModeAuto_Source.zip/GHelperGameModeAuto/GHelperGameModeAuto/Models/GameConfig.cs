using System;
using System.Text.Json.Serialization;

namespace GHelperGameModeAuto.Models;

public class GameConfig
{
	public string Id { get; set; } = Guid.NewGuid().ToString("N");


	public string Name { get; set; } = string.Empty;


	public string ProcessName { get; set; } = string.Empty;


	public string ExecutablePath { get; set; } = string.Empty;


	public GHelperMode LaunchMode { get; set; } = GHelperMode.Turbo;


	public ExitModeType ExitBehavior { get; set; }

	public GHelperMode FixedExitMode { get; set; } = GHelperMode.Balanced;


	public bool IsEnabled { get; set; } = true;


	public string Platform { get; set; } = "Manual";


	[JsonIgnore]
	public string CleanProcessName
	{
		get
		{
			string processName = ProcessName?.Trim() ?? string.Empty;
			if (string.IsNullOrEmpty(processName))
			{
				return string.Empty;
			}
			try
			{
				if (processName.Contains('\\') || processName.Contains('/'))
				{
					return System.IO.Path.GetFileNameWithoutExtension(processName);
				}
			}
			catch
			{
			}
			if (processName.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
			{
				return processName.Substring(0, processName.Length - 4);
			}
			return processName;
		}
	}

	[JsonIgnore]
	public string ExitSummary
	{
		get
		{
			if (ExitBehavior != 0)
			{
				return "固定为: " + FixedExitMode.ToShortName();
			}
			return "恢复启动前模式";
		}
	}

	public GameConfig Clone()
	{
		return new GameConfig
		{
			Id = Id,
			Name = Name,
			ProcessName = ProcessName,
			ExecutablePath = ExecutablePath,
			LaunchMode = LaunchMode,
			ExitBehavior = ExitBehavior,
			FixedExitMode = FixedExitMode,
			IsEnabled = IsEnabled,
			Platform = Platform
		};
	}
}
