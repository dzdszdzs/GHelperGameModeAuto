namespace GHelperGameModeAuto.Models;

public enum ExitModeType
{
	RestorePrevious,
	FixedMode
}
