namespace GHelperGameModeAuto.Models;

public enum GHelperMode
{
	Silent,
	Balanced,
	Turbo,
	Custom1,
	Custom2
}
