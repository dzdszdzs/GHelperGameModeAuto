using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace GHelperGameModeAuto.Models;

public class HotkeyConfig
{
	public bool Ctrl { get; set; } = true;


	public bool Shift { get; set; } = true;


	public bool Alt { get; set; } = true;


	public bool Win { get; set; }

	public string Key { get; set; } = "F16";


	public byte VirtualKey { get; set; } = 127;


	[JsonIgnore]
	public string DisplayText
	{
		get
		{
			List<string> list = new List<string>();
			if (Ctrl)
			{
				list.Add("Ctrl");
			}
			if (Shift)
			{
				list.Add("Shift");
			}
			if (Alt)
			{
				list.Add("Alt");
			}
			if (Win)
			{
				list.Add("Win");
			}
			list.Add(string.IsNullOrWhiteSpace(Key) ? "None" : Key);
			return string.Join(" + ", list);
		}
	}

	public static HotkeyConfig CreateDefault(GHelperMode mode)
	{
		return mode switch
		{
			GHelperMode.Silent => new HotkeyConfig
			{
				Ctrl = true,
				Shift = true,
				Alt = true,
				Win = false,
				Key = "F16",
				VirtualKey = 127
			}, 
			GHelperMode.Balanced => new HotkeyConfig
			{
				Ctrl = true,
				Shift = true,
				Alt = true,
				Win = false,
				Key = "F17",
				VirtualKey = 128
			}, 
			GHelperMode.Turbo => new HotkeyConfig
			{
				Ctrl = true,
				Shift = true,
				Alt = true,
				Win = false,
				Key = "F18",
				VirtualKey = 129
			}, 
			GHelperMode.Custom1 => new HotkeyConfig
			{
				Ctrl = true,
				Shift = true,
				Alt = true,
				Win = false,
				Key = "F19",
				VirtualKey = 130
			}, 
			GHelperMode.Custom2 => new HotkeyConfig
			{
				Ctrl = true,
				Shift = true,
				Alt = true,
				Win = false,
				Key = "F20",
				VirtualKey = 131
			}, 
			_ => new HotkeyConfig(), 
		};
	}

	public HotkeyConfig Clone()
	{
		return new HotkeyConfig
		{
			Ctrl = Ctrl,
			Shift = Shift,
			Alt = Alt,
			Win = Win,
			Key = Key,
			VirtualKey = VirtualKey
		};
	}
}
