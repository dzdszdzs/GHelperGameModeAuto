using System.Collections.Generic;

namespace GHelperGameModeAuto.Models;

public class AppSettings
{
	public bool AutoStart { get; set; }

	public bool MinimizeToTrayOnClose { get; set; } = true;


	public bool StartMinimized { get; set; }

	public int PollingIntervalMs { get; set; } = 3000;


	public bool IsPaused { get; set; }

	public GHelperMode DefaultBaselineMode { get; set; } = GHelperMode.Balanced;


	public Dictionary<string, HotkeyConfig> Hotkeys { get; set; } = new Dictionary<string, HotkeyConfig>
	{
		{
			GHelperMode.Silent.ToString(),
			HotkeyConfig.CreateDefault(GHelperMode.Silent)
		},
		{
			GHelperMode.Balanced.ToString(),
			HotkeyConfig.CreateDefault(GHelperMode.Balanced)
		},
		{
			GHelperMode.Turbo.ToString(),
			HotkeyConfig.CreateDefault(GHelperMode.Turbo)
		},
		{
			GHelperMode.Custom1.ToString(),
			HotkeyConfig.CreateDefault(GHelperMode.Custom1)
		},
		{
			GHelperMode.Custom2.ToString(),
			HotkeyConfig.CreateDefault(GHelperMode.Custom2)
		}
	};


	public List<GameConfig> Games { get; set; } = new List<GameConfig>();


	public HotkeyConfig GetHotkey(GHelperMode mode)
	{
		string key = mode.ToString();
		if (!Hotkeys.TryGetValue(key, out HotkeyConfig value))
		{
			value = HotkeyConfig.CreateDefault(mode);
			Hotkeys[key] = value;
		}
		return value;
	}

	public void SetHotkey(GHelperMode mode, HotkeyConfig config)
	{
		Hotkeys[mode.ToString()] = config;
	}
}
