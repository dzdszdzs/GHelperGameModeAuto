namespace GHelperGameModeAuto.Models;

public static class ExitModeTypeExtensions
{
	public static string ToDisplayName(this ExitModeType type)
	{
		return type switch
		{
			ExitModeType.RestorePrevious => "恢复启动前模式", 
			ExitModeType.FixedMode => "固定退出模式", 
			_ => type.ToString(), 
		};
	}
}
