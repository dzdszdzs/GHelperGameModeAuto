namespace GHelperGameModeAuto.Models;

public static class GHelperModeExtensions
{
	public static string ToDisplayName(this GHelperMode mode)
	{
		return mode switch
		{
			GHelperMode.Silent => "静音 (Silent)", 
			GHelperMode.Balanced => "平衡 (Balanced)", 
			GHelperMode.Turbo => "增强 (Turbo)", 
			GHelperMode.Custom1 => "自定义 1 (Custom 1)", 
			GHelperMode.Custom2 => "自定义 2 (Custom 2)", 
			_ => mode.ToString(), 
		};
	}

	public static string ToShortName(this GHelperMode mode)
	{
		return mode switch
		{
			GHelperMode.Silent => "静音", 
			GHelperMode.Balanced => "平衡", 
			GHelperMode.Turbo => "增强", 
			GHelperMode.Custom1 => "自定义 1", 
			GHelperMode.Custom2 => "自定义 2", 
			_ => mode.ToString(), 
		};
	}

	public static string GetColorHex(this GHelperMode mode)
	{
		return mode switch
		{
			GHelperMode.Silent => "#3B82F6", 
			GHelperMode.Balanced => "#10B981", 
			GHelperMode.Turbo => "#EF4444", 
			GHelperMode.Custom1 => "#F59E0B", 
			GHelperMode.Custom2 => "#8B5CF6", 
			_ => "#6B7280", 
		};
	}

	public static string GetIconSymbol(this GHelperMode mode)
	{
		return mode switch
		{
			GHelperMode.Silent => "\ud83c\udf43", 
			GHelperMode.Balanced => "⚖\ufe0f", 
			GHelperMode.Turbo => "⚡", 
			GHelperMode.Custom1 => "\ud83d\udee0\ufe0f", 
			GHelperMode.Custom2 => "⚙\ufe0f", 
			_ => "\ud83d\udcbb", 
		};
	}
}
