using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using GHelperGameModeAuto.Services;

namespace GHelperGameModeAuto;

public class App : Application
{
	private const string MutexName = "Global\\GHelperGameModeAuto_SingleInstance_Mutex";

	private Mutex? _instanceMutex;

	private ConfigService? _configService;

	private ProcessMonitorService? _monitorService;

	private MainWindow? _mainWindow;

	private bool _contentLoaded;

	public TrayIconManager? TrayManager { get; private set; }

	protected override void OnStartup(StartupEventArgs e)
	{
		base.OnStartup(e);
		_instanceMutex = new Mutex(initiallyOwned: true, "Global\\GHelperGameModeAuto_SingleInstance_Mutex", out var createdNew);
		if (!createdNew)
		{
			MessageBox.Show("G-Helper 游戏模式自动切换程序已在运行中。\n可查看系统右下角托盘图标。", "提示", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			Application.Current.Shutdown();
			return;
		}
		Logger.Info("========== 应用程序启动 ==========");
		_configService = new ConfigService();
		_monitorService = new ProcessMonitorService(_configService);
		TrayManager = new TrayIconManager(_monitorService, _configService, ShowMainWindow, ExitApplication);
		bool flag = _configService.Current.StartMinimized;
		if (e.Args.Any((string a) => a.Equals("--minimized", StringComparison.OrdinalIgnoreCase) || a.Equals("-m", StringComparison.OrdinalIgnoreCase) || a.Equals("--tray", StringComparison.OrdinalIgnoreCase)))
		{
			flag = true;
		}
		if (!flag)
		{
			ShowMainWindow();
			return;
		}
		Logger.Info("程序以后台最小化至托盘模式启动");
		Task.Delay(500).ContinueWith(delegate
		{
			MemoryOptimizer.TrimMemory();
		});
	}

	public void ShowMainWindow()
	{
		if (_mainWindow == null)
		{
			_mainWindow = new MainWindow(_configService, _monitorService);
		}
		if (!_mainWindow.IsVisible)
		{
			_mainWindow.Show();
		}
		if (_mainWindow.WindowState == WindowState.Minimized)
		{
			_mainWindow.WindowState = WindowState.Normal;
		}
		_mainWindow.Activate();
		_mainWindow.Focus();
	}

	public void ExitApplication()
	{
		Logger.Info("用户触发退出程序");
		_mainWindow?.ForceExit();
		Application.Current.Shutdown();
	}

	protected override void OnExit(ExitEventArgs e)
	{
		Logger.Info("正在安全释放资源并退出...");
		TrayManager?.Dispose();
		_monitorService?.Dispose();
		if (_instanceMutex != null)
		{
			try
			{
				_instanceMutex.ReleaseMutex();
			}
			catch
			{
			}
			_instanceMutex.Dispose();
		}
		base.OnExit(e);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/GHelperGameModeAuto;component/app.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[STAThread]
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "8.0.31.0")]
	public static void Main()
	{
		App app = new App();
		app.InitializeComponent();
		app.Run();
	}
}
